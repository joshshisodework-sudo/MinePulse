/**
 * MINEWATCH - Mine Subsidence Monitoring System JS
 * High Fidelity Interactive Implementation matching User Specification
 */

// Location Presets Node Database (Underground Coal Mines of India)
const COALFIELD_PRESETS = {
    "23.3242,82.5278": {
        name: "Churcha Underground Mine, Chhattisgarh",
        lat: 23.3242,
        lng: 82.5278,
        count: 30
    },
    "23.7420,86.3560": {
        name: "Moonidih Underground Mine, Jharkhand",
        lat: 23.7420,
        lng: 86.3560,
        count: 24
    },
    "17.5140,80.6270": {
        name: "VK7 Underground Mine (SCCL), Telangana",
        lat: 17.5140,
        lng: 80.6270,
        count: 20
    },
    "23.6200,87.1300": {
        name: "Raniganj Underground Belt, West Bengal",
        lat: 23.6200,
        lng: 87.1300,
        count: 18
    },
    "23.1800,82.3500": {
        name: "Chirimiri Underground Complex, Chhattisgarh",
        lat: 23.1800,
        lng: 82.3500,
        count: 15
    }
};

let activeNodesList = [];

// Dynamic Node Generator around a center coordinate
function generateNodesForLocation(centerLat, centerLng, count) {
    const nodes = [];
    
    // Rings ratio
    const ring1 = Math.max(1, Math.ceil(count * 0.15)); // inner risk center
    const ring2 = Math.ceil(count * 0.4); // mid ring
    const ring3 = count - ring1 - ring2; // outer ring

    let nodeIndex = 1;

    // Helper to add a node
    function addNode(ring, indexInRing, totalInRing, status, radiusScale) {
        const angle = (indexInRing / totalInRing) * Math.PI * 2;
        const latOffset = Math.sin(angle) * 0.003 * radiusScale;
        const lngOffset = Math.cos(angle) * 0.004 * radiusScale;
        
        const latNum = centerLat + latOffset;
        const lngNum = centerLng + lngOffset;

        const padId = nodeIndex < 10 ? `N0${nodeIndex}` : `N${nodeIndex}`;

        let dispVal = 0.4;
        let tiltXVal = 0.05;
        let tiltYVal = 0.04;
        let vibVal = 0.02;

        if (status === 'high') {
            dispVal = 3.2;
            tiltXVal = 0.42;
            tiltYVal = 0.31;
            vibVal = 0.08;
        } else if (status === 'moderate') {
            dispVal = 2.4;
            tiltXVal = 0.28;
            tiltYVal = 0.22;
            vibVal = 0.06;
        }

        nodes.push({
            id: padId,
            status: status,
            x: 50 + (lngOffset / 0.004) * 20,
            y: 42 - (latOffset / 0.003) * 20,
            latNum: latNum,
            lngNum: lngNum,
            lat: `${latNum.toFixed(4)}° N`,
            lng: `${lngNum.toFixed(4)}° E`,
            elev: Math.round(210 + Math.random() * 30),
            bat: Math.round(75 + Math.random() * 23),
            sig: Math.round(-88 + Math.random() * 15),
            tiltX: tiltXVal,
            tiltY: tiltYVal,
            disp: dispVal,
            vib: vibVal,
            crack: status === 'high' ? 0.4 : 0.1,
            temp: 28.6
        });

        nodeIndex++;
    }

    // Node N16 is designated High Risk in center
    for (let i = 0; i < ring1; i++) {
        const status = i === 0 ? 'high' : 'moderate';
        addNode(1, i, ring1, status, 0.35);
    }

    // Mid ring (Warning & Normal)
    for (let i = 0; i < ring2; i++) {
        const status = (i % 3 === 0) ? 'moderate' : 'normal';
        addNode(2, i, ring2, status, 0.85);
    }

    // Outer ring (Normal)
    for (let i = 0; i < ring3; i++) {
        addNode(3, i, ring3, 'normal', 1.4);
    }

    return nodes;
}

document.addEventListener('DOMContentLoaded', () => {

    // Application State
    let selectedNodeId = "N16";
    let isHeatmapVisible = false;
    let currentCenterLat = 23.3242;
    let currentCenterLng = 82.5278;
    
    // Leaflet map instances
    let leafletMap = null;
    let leafletMarkers = [];

    // Chart instances
    let tiltChartInstance = null;
    let dispChartInstance = null;
    let vibChartInstance = null;

    // Initialize Default Nodes for Churcha Underground Mine, Chhattisgarh (30 nodes)
    activeNodesList = generateNodesForLocation(23.3242, 82.5278, 30);

    // ================= 1. INITIALIZE LIVE CLOCK =================
    function initClock() {
        const dateEl = document.getElementById('header-date');
        const timeEl = document.getElementById('header-time');

        function updateClock() {
            const now = new Date();
            const options = { day: '2-digit', month: 'short', year: 'numeric' };
            if (dateEl) dateEl.textContent = now.toLocaleDateString('en-GB', options);
            
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            if (timeEl) timeEl.textContent = `${hours}:${minutes}`;
        }
        
        updateClock();
        setInterval(updateClock, 1000);
    }

    // ================= 2. HEATMAP CANVAS =================
    function drawHeatmap(canvasId = 'heatmap-canvas') {
        const canvas = document.getElementById(canvasId);
        if (!canvas || !canvas.parentElement) return;
        const ctx = canvas.getContext('2d');
        const width = canvas.width = canvas.parentElement.clientWidth;
        const height = canvas.height = canvas.parentElement.clientHeight;

        ctx.clearRect(0, 0, width, height);

        if (!isHeatmapVisible || activeNodesList.length === 0) return;

        const centerX = width * 0.50;
        const centerY = height * 0.45;
        const outerRad = Math.min(width, height) * 0.35;

        const grad = ctx.createRadialGradient(centerX, centerY, 5, centerX, centerY, outerRad);
        grad.addColorStop(0.0, 'rgba(239, 68, 68, 0.85)');
        grad.addColorStop(0.2, 'rgba(249, 115, 22, 0.75)');
        grad.addColorStop(0.45, 'rgba(234, 179, 8, 0.65)');
        grad.addColorStop(0.7, 'rgba(34, 197, 94, 0.45)');
        grad.addColorStop(1.0, 'rgba(34, 197, 94, 0.0)');

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(centerX, centerY, outerRad, 0, Math.PI * 2);
        ctx.fill();
    }

    // ================= 3. LEAFLET REAL SATELLITE MAP =================
    function initLeafletMap() {
        const mapContainer = document.getElementById('leaflet-map');
        if (!mapContainer || leafletMap) return;

        leafletMap = L.map('leaflet-map', {
            center: [currentCenterLat, currentCenterLng],
            zoom: 15,
            zoomControl: false
        });

        // Esri World Imagery Satellite Tile Layer
        L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: 'Esri Satellite Imagery',
            maxZoom: 18
        }).addTo(leafletMap);

        renderLeafletMarkers(leafletMap, leafletMarkers);
        if (typeof loadSavedCrackReports === 'function') loadSavedCrackReports();

        leafletMap.on('move end zoomend', () => {
            drawHeatmap('heatmap-canvas');
        });
    }

    // Render Markers for current activeNodesList with Soft Aura Halos
    function renderLeafletMarkers(targetMap, markerArray) {
        if (!targetMap) return;

        // Clear existing markers
        markerArray.forEach(m => targetMap.removeLayer(m));
        markerArray.length = 0;

        activeNodesList.forEach(node => {
            const statusClass = node.status;
            const isSelected = node.id === selectedNodeId;

            const customIcon = L.divIcon({
                className: 'custom-leaflet-node',
                html: `
                    <div class="map-node ${statusClass} ${isSelected ? 'selected' : ''}">
                        <div class="node-aura"></div>
                        <div class="node-dot"></div>
                        <span class="node-label">${node.id}</span>
                    </div>
                `,
                iconSize: [44, 44],
                iconAnchor: [22, 22]
            });

            const marker = L.marker([node.latNum, node.lngNum], { icon: customIcon }).addTo(targetMap);
            
            marker.bindTooltip(`<b>Node ${node.id}</b><br>Status: ${node.status.toUpperCase()}<br>Battery: ${node.bat}%`, {
                direction: 'top',
                offset: [0, -15]
            });

            marker.on('click', () => {
                selectNode(node.id);
            });

            markerArray.push(marker);
        });

        updateStatCounters();
    }

    // Update Top Stat Cards Counters
    function updateStatCounters() {
        const onlineEl = document.getElementById('stat-online-nodes');
        const offlineSub = document.getElementById('stat-offline-nodes');
        const highestRiskVal = document.getElementById('stat-highest-risk-val');
        const highestRiskNode = document.getElementById('stat-highest-risk-node');

        const totalCount = activeNodesList.length;
        const offlineCount = activeNodesList.filter(n => n.status === 'high' || n.status === 'offline').length;
        const onlineCount = totalCount - offlineCount;

        if (onlineEl) onlineEl.textContent = `${onlineCount}`;
        if (offlineSub) offlineSub.innerHTML = `${offlineCount} <span data-i18n="offlineWord">Offline</span>`;
        
        const highNode = activeNodesList.find(n => n.status === 'high') || activeNodesList[0];
        if (highNode && highestRiskVal) highestRiskVal.textContent = "0.82";
        if (highNode && highestRiskNode) highestRiskNode.innerHTML = `<span data-i18n="nodeWord">Node</span> ${highNode.id}`;
    }

    // ================= 4. LAT/LNG SEARCH & DYNAMIC NODE PLANTING =================
    function initLatLngControls() {
        const latInput = document.getElementById('map-lat-input');
        const lngInput = document.getElementById('map-lng-input');
        const goBtn = document.getElementById('go-to-latlng-btn');
        const presetSelect = document.getElementById('quick-location-select');
        const plantCountInput = document.getElementById('plant-node-count-input');
        const plantBtn = document.getElementById('plant-nodes-btn');
        const clearBtn = document.getElementById('clear-nodes-btn');

        function refreshAllMapViews() {
            if (leafletMap) renderLeafletMarkers(leafletMap, leafletMarkers);
            drawHeatmap('heatmap-canvas');
            
            if (typeof renderSequentialNodesTable === 'function') {
                const searchInput = document.getElementById('node-search-input');
                const statusFilter = document.getElementById('node-status-filter');
                const text = searchInput ? searchInput.value : '';
                const status = statusFilter ? statusFilter.value : 'all';
                renderSequentialNodesTable(text, status);
            }

            if (activeNodesList.length > 0) {
                selectNode(activeNodesList[0].id);
            }
        }

        // Helper to navigate and plant
        function navigateToCoordsAndPlant(lat, lng, count) {
            currentCenterLat = parseFloat(lat);
            currentCenterLng = parseFloat(lng);

            if (leafletMap) leafletMap.flyTo([currentCenterLat, currentCenterLng], 15, { duration: 1.2 });

            if (latInput) latInput.value = currentCenterLat.toFixed(4);
            if (lngInput) lngInput.value = currentCenterLng.toFixed(4);

            // Plant new nodes for this location
            activeNodesList = generateNodesForLocation(currentCenterLat, currentCenterLng, count);
            refreshAllMapViews();
        }

        // 1. Go to custom Lat/Lng
        if (goBtn) {
            goBtn.addEventListener('click', () => {
                const lat = latInput ? latInput.value : '23.3242';
                const lng = lngInput ? lngInput.value : '82.5278';
                navigateToCoordsAndPlant(lat, lng, 30);
            });
        }

        // 2. Preset Select Coalfield Switcher
        if (presetSelect) {
            presetSelect.addEventListener('change', (e) => {
                const val = e.target.value;
                const preset = COALFIELD_PRESETS[val];
                if (preset) {
                    if (plantCountInput) plantCountInput.value = preset.count;
                    navigateToCoordsAndPlant(preset.lat, preset.lng, preset.count);
                } else {
                    const [lat, lng] = val.split(',');
                    navigateToCoordsAndPlant(lat, lng, 30);
                }
            });
        }

        // 3. Plant Nodes Button
        if (plantBtn) {
            plantBtn.addEventListener('click', () => {
                const count = plantCountInput ? parseInt(plantCountInput.value) || 20 : 20;
                activeNodesList = generateNodesForLocation(currentCenterLat, currentCenterLng, count);
                refreshAllMapViews();
            });
        }

        // 4. Clear Nodes Button ("nodes gaayab")
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                activeNodesList = [];
                refreshAllMapViews();
            });
        }
    }

    // ================= 5. SELECT NODE & UPDATE TELEMETRY PANEL =================
    window.selectNode = function(nodeId, shouldZoom = false) {
        selectedNodeId = nodeId;

        if (leafletMap) renderLeafletMarkers(leafletMap, leafletMarkers);

        const node = activeNodesList.find(n => n.id === nodeId) || activeNodesList[0];
        if (!node) return;

        const elId = document.getElementById('sel-node-id');
        if (elId) elId.textContent = node.id;
        
        const elLoc = document.getElementById('sel-node-location');
        if (elLoc) elLoc.textContent = `${node.lat}, ${node.lng}`;
        
        const elElev = document.getElementById('sel-node-elevation');
        if (elElev) elElev.textContent = `${node.elev} m`;
        
        const elBat = document.getElementById('sel-node-battery');
        if (elBat) elBat.textContent = `${node.bat}%`;
        
        const rTiltX = document.getElementById('read-tilt-x');
        if (rTiltX) rTiltX.textContent = node.tiltX.toFixed(2);
        
        const rTiltY = document.getElementById('read-tilt-y');
        if (rTiltY) rTiltY.textContent = node.tiltY.toFixed(2);
        
        const rDisp = document.getElementById('read-disp');
        if (rDisp) rDisp.textContent = node.disp.toFixed(1);
        
        const rVib = document.getElementById('read-vib');
        if (rVib) rVib.textContent = node.vib.toFixed(2);
        
        const rCrack = document.getElementById('read-crack');
        if (rCrack) rCrack.textContent = node.crack.toFixed(1);
        
        const rTemp = document.getElementById('read-temp');
        if (rTemp) rTemp.textContent = node.temp.toFixed(1);

        const badge = document.getElementById('sel-node-status-badge');
        if (badge) {
            badge.textContent = node.status === 'high' ? 'High Risk' : (node.status === 'moderate' ? 'Warning' : 'Normal');
            badge.className = `badge ${node.status === 'high' ? 'danger' : (node.status === 'moderate' ? 'warning' : 'online')}`;
        }

        document.querySelectorAll('.chart-node-id').forEach(el => {
            el.textContent = node.id;
        });

        updateCharts(node);

        if (shouldZoom && leafletMap) {
            leafletMap.flyTo([node.latNum, node.lngNum], 18, { duration: 1.2 });
        }
    };

    // ================= 6. CHART.JS TRENDS INITIALIZATION =================
    function initCharts() {
        const ctxTilt = document.getElementById('tiltChart');
        const ctxDisp = document.getElementById('dispChart');
        const ctxVib = document.getElementById('vibChart');

        const hours = ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00', '14:30'];

        if (ctxTilt) {
            tiltChartInstance = new Chart(ctxTilt, {
                type: 'line',
                data: {
                    labels: hours,
                    datasets: [
                        { label: 'Tilt X (°)', data: [0.05, 0.08, 0.12, 0.25, 0.35, 0.40, 0.42], borderColor: '#dc2626', backgroundColor: 'rgba(220,38,38,0.08)', fill: true, tension: 0.3 },
                        { label: 'Tilt Y (°)', data: [0.04, 0.06, 0.09, 0.18, 0.24, 0.29, 0.31], borderColor: '#f59e0b', backgroundColor: 'transparent', tension: 0.3 }
                    ]
                },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
            });
        }

        if (ctxDisp) {
            dispChartInstance = new Chart(ctxDisp, {
                type: 'line',
                data: {
                    labels: hours,
                    datasets: [
                        { label: 'Displacement (mm)', data: [0.4, 0.6, 1.1, 1.8, 2.5, 2.9, 3.2], borderColor: '#dc2626', backgroundColor: 'rgba(220,38,38,0.1)', fill: true, tension: 0.3 }
                    ]
                },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
            });
        }

        if (ctxVib) {
            vibChartInstance = new Chart(ctxVib, {
                type: 'bar',
                data: {
                    labels: hours,
                    datasets: [
                        { label: 'Vibration RMS (g)', data: [0.02, 0.03, 0.05, 0.04, 0.07, 0.06, 0.08], backgroundColor: '#2563eb' }
                    ]
                },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
            });
        }
    }

    function updateCharts(node) {
        if (!tiltChartInstance) return;
        const multiplier = node.status === 'high' ? 1.0 : (node.status === 'moderate' ? 0.6 : 0.2);

        tiltChartInstance.data.datasets[0].data = [0.05, 0.08, 0.12, 0.25, 0.35, 0.40, node.tiltX];
        tiltChartInstance.data.datasets[1].data = [0.04, 0.06, 0.09, 0.18, 0.24, 0.29, node.tiltY];
        tiltChartInstance.update();

        if (dispChartInstance) {
            dispChartInstance.data.datasets[0].data = [0.4, 0.6, 1.1, 1.8, 2.5, 2.9, node.disp];
            dispChartInstance.update();
        }

        if (vibChartInstance) {
            vibChartInstance.data.datasets[0].data = [0.02, 0.03, 0.05, 0.04, 0.07, 0.06, node.vib];
            vibChartInstance.update();
        }
    }

    // ================= 7. MAP CONTROLS & EVENT HANDLERS =================
    function initMapControls() {
        const toggleHeatmapBtn = document.getElementById('toggle-heatmap-btn');

        if (toggleHeatmapBtn) {
            toggleHeatmapBtn.addEventListener('click', () => {
                isHeatmapVisible = !isHeatmapVisible;
                toggleHeatmapBtn.classList.toggle('active', isHeatmapVisible);
                drawHeatmap('heatmap-canvas');
            });
        }

        const zoomInBtn = document.getElementById('map-zoom-in');
        const zoomOutBtn = document.getElementById('map-zoom-out');
        if (zoomInBtn) zoomInBtn.addEventListener('click', () => leafletMap && leafletMap.zoomIn());
        if (zoomOutBtn) zoomOutBtn.addEventListener('click', () => leafletMap && leafletMap.zoomOut());
        
        const highRiskBanner = document.getElementById('high-risk-banner');
        if (highRiskBanner) {
            highRiskBanner.addEventListener('click', () => {
                selectNode('N16');
                if (leafletMap) leafletMap.flyTo([currentCenterLat, currentCenterLng], 16, { duration: 1.0 });
            });
        }

        const toggleChartsBtn = document.getElementById('toggle-charts-btn');
        const analyticsBody = document.getElementById('analytics-body');
        if (toggleChartsBtn && analyticsBody) {
            toggleChartsBtn.addEventListener('click', () => {
                const isHidden = analyticsBody.style.display === 'none';
                analyticsBody.style.display = isHidden ? 'block' : 'none';
                const chevron = toggleChartsBtn.querySelector('.toggle-chevron');
                if (chevron) chevron.style.transform = isHidden ? 'rotate(180deg)' : 'rotate(0deg)';
            });
        }
    }

    // ================= 8. SEQUENTIAL NODES DIRECTORY & SEARCH =================
    function renderSequentialNodesTable(filterText = '', statusFilter = 'all') {
        const tbody = document.getElementById('sequential-nodes-tbody');
        if (!tbody) return;

        tbody.innerHTML = '';
        
        let filteredNodes = activeNodesList.filter(node => {
            const matchesSearch = node.id.toLowerCase().includes(filterText.toLowerCase());
            const matchesStatus = statusFilter === 'all' || node.status === statusFilter;
            return matchesSearch && matchesStatus;
        });

        filteredNodes.forEach(node => {
            const tr = document.createElement('tr');
            
            let statusBadge = '';
            if (node.status === 'high') statusBadge = '<span class="badge danger">High Risk</span>';
            else if (node.status === 'moderate') statusBadge = '<span class="badge warning">Warning</span>';
            else statusBadge = '<span class="badge online">Normal</span>';

            tr.innerHTML = `
                <td><strong>${node.id}</strong></td>
                <td>${statusBadge}</td>
                <td>${node.latNum.toFixed(4)}</td>
                <td>${node.lngNum.toFixed(4)}</td>
                <td class="${node.tiltX > 0.3 ? 'red-text' : ''}">${node.tiltX.toFixed(2)}°</td>
                <td class="${node.tiltY > 0.2 ? 'red-text' : ''}">${node.tiltY.toFixed(2)}°</td>
                <td>${node.vib.toFixed(2)} g</td>
                <td>${node.temp.toFixed(1)} °C</td>
                <td class="${node.bat < 20 ? 'red-text' : ''}">${node.bat}%</td>
                <td>
                    <button class="latlng-go-btn" style="padding: 4px 8px; font-size: 0.8rem;" onclick="selectNode('${node.id}', true)"><span data-i18n="action">View</span></button>
                    <button class="latlng-go-btn" style="padding: 4px 8px; font-size: 0.8rem; margin-left: 4px; background: #3b82f6;" onclick="openNodeDiagnosticsModal('${node.id}')"><span data-i18n="nodeDiagnostics">Node Diagnostics</span></button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    }

    function initNodeSearchAndFilter() {
        const searchInput = document.getElementById('node-search-input');
        const statusFilter = document.getElementById('node-status-filter');
        const clearBtn = document.getElementById('clear-search-btn');

        function updateTable() {
            const text = searchInput ? searchInput.value : '';
            const status = statusFilter ? statusFilter.value : 'all';
            renderSequentialNodesTable(text, status);
        }

        if (searchInput) searchInput.addEventListener('input', updateTable);
        if (statusFilter) statusFilter.addEventListener('change', updateTable);
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                if (searchInput) searchInput.value = '';
                if (statusFilter) statusFilter.value = 'all';
                updateTable();
            });
        }
    }

    // ================= 9. MULTILINGUAL SWITCHER =================
    function initLanguageSwitcher() {
        const langSelect = document.getElementById('language-switcher');
        if (!langSelect) return;

        const translations = {
            "hi": {
                        "brandName": "माइनवॉच",
                        "brandSubtitle": "खदान धंसने की निगरानी",
                        "nodesOnline": "सक्रिय नोड्स",
                        "activeAlerts": "सक्रिय अलर्ट",
                        "highestRisk": "उच्चतम जोखिम",
                        "systemOperational": "प्रणाली चालू है",
                        "recentAlerts": "हाल के अलर्ट",
                        "nodesDirectory": "क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "नोड आईडी",
                        "status": "स्थिति",
                        "lat": "अक्षांश:",
                        "lng": "देशांतर:",
                        "go": "जाओ",
                        "churchaMine": "📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "नोड्स:",
                        "plant": "लगाएं",
                        "clear": "साफ़ करें",
                        "nodeWord": "नोड",
                        "offlineWord": "ऑफ़लाइन",
                        "highRiskIndicators": "उच्च जोखिम संकेतक",
                        "increasingDisplacement": "बढ़ता विस्थापन",
                        "elevatedVibration": "उच्च कंपन",
                        "highRisk": "उच्च जोखिम",
                        "warning": "चेतावनी",
                        "normal": "सामान्य",
                        "high": "उच्च",
                        "highRiskZoneDetected": "उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "झुकाव (X)",
                        "tiltY": "झुकाव (Y)",
                        "displacement": "विस्थापन",
                        "vibration": "कंपन (RMS)",
                        "crackWidth": "दरार की चौड़ाई",
                        "temperature": "तापमान",
                        "action": "कार्रवाई",
                        "elevation": "ऊंचाई",
                        "battery": "बैटरी",
                        "nodeDiagnostics": "नोड डायग्नोस्टिक्स",
                        "logCrack": "दरार दर्ज करें"
            },
            "or": {
                        "brandName": "ମାଇନ୍ ୱାଚ୍",
                        "brandSubtitle": "ଖଣି ଦବିବା ତଦାରଖ",
                        "nodesOnline": "ସକ୍ରିୟ ନୋଡ୍",
                        "activeAlerts": "ସକ୍ରିୟ ସତର୍କତା",
                        "highestRisk": "ସର୍ବାଧିକ ବିପଦ",
                        "systemOperational": "ସିଷ୍ଟମ୍ କାର୍ଯ୍ୟକ୍ଷମ",
                        "recentAlerts": "ସାମ୍ପ୍ରତିକ ସତର୍କତା",
                        "nodesDirectory": "କ୍ରମିକ ସେନ୍ସର ନୋଡ୍ ଡିରେକ୍ଟୋରୀ",
                        "nodeId": "ନୋଡ୍ ଆଇଡି",
                        "status": "ସ୍ଥିତି",
                        "lat": "ଅକ୍ଷାଂଶ:",
                        "lng": "ଦ୍ରାଘିମା:",
                        "go": "ଯାଆନ୍ତୁ",
                        "churchaMine": "📍 ଚର୍ଚ୍ଚା ଭୂତଳ ଖଣି, ଛତିଶଗଡ (୩୦ ନୋଡ୍)",
                        "moonidihMine": "📍 ମୁନିଡିହ ଭୂତଳ ଖଣି, ଝାଡଖଣ୍ଡ (୨୪ ନୋଡ୍)",
                        "vk7Mine": "📍 ଭିକେ୭ ଭୂତଳ ଖଣି (SCCL), ତେଲେଙ୍ଗାନା (୨୦ ନୋଡ୍)",
                        "raniganjBelt": "📍 ରାଣୀଗଞ୍ଜ ଭୂତଳ ବେଲ୍ଟ, ପଶ୍ଚିମବଙ୍ଗ (୧୮ ନୋଡ୍)",
                        "chirimiriMine": "📍 ଚିରିମିରି ଭୂତଳ କମ୍ପ୍ଲେକ୍ସ, ଛତିଶଗଡ (୧୫ ନୋଡ୍)",
                        "nodes": "ନୋଡ୍:",
                        "plant": "ଲଗାନ୍ତୁ",
                        "clear": "ସଫା କରନ୍ତୁ",
                        "nodeWord": "ନୋଡ୍",
                        "offlineWord": "ଅଫଲାଇନ୍",
                        "highRiskIndicators": "ଉଚ୍ଚ ବିପଦ ସୂଚକ",
                        "increasingDisplacement": "ବୃଦ୍ଧି ପାଉଥିବା ବିସ୍ଥାପନ",
                        "elevatedVibration": "ଉଚ୍ଚ କମ୍ପନ",
                        "highRisk": "ଉଚ୍ଚ ବିପଦ",
                        "warning": "ଚେତାବନୀ",
                        "normal": "ସାଧାରଣ",
                        "high": "ଉଚ୍ଚ",
                        "highRiskZoneDetected": "ଉଚ୍ଚ ବିପଦ ଅଞ୍ଚଳ ଚିହ୍ନଟ ହୋଇଛି",
                        "potentialSubsidence": "ସମ୍ଭାବ୍ୟ ଦବିବା ଗତିବିଧି",
                        "detailedTelemetry": "ବିସ୍ତୃତ ଟେଲିମେଟ୍ରି ବିଶ୍ଳେଷଣ",
                        "tiltX": "ଢାଲ (X)",
                        "tiltY": "ଢାଲ (Y)",
                        "displacement": "ବିସ୍ଥାପନ",
                        "vibration": "କମ୍ପନ (RMS)",
                        "crackWidth": "ଫାଟର ପ୍ରସ୍ଥ",
                        "temperature": "ତାପମାତ୍ରା",
                        "action": "କାର୍ଯ୍ୟ",
                        "elevation": "ଉଚ୍ଚତା",
                        "battery": "ବ୍ୟାଟେରୀ",
                        "nodeDiagnostics": "ନୋଡ୍ ଡାଇଗ୍ନୋଷ୍ଟିକ୍ସ",
                        "logCrack": "ଫାଟ ଦର୍ଜ କରନ୍ତୁ"
            },
            "bn": {
                        "brandName": "মাইনওয়াচ",
                        "brandSubtitle": "খনি ধস পর্যবেক্ষণ",
                        "nodesOnline": "সক্রিয় নোড",
                        "activeAlerts": "সক্রিয় সতর্কতা",
                        "highestRisk": "সর্বোচ্চ ঝুঁকি",
                        "systemOperational": "সিস্টেম চালু আছে",
                        "recentAlerts": "সাম্প্রতিক সতর্কতা",
                        "nodesDirectory": "ক্রমিক সেন্সর নোড ডিরেক্টরি",
                        "nodeId": "নোড আইডি",
                        "status": "অবস্থা",
                        "lat": "অক্ষাংশ:",
                        "lng": "দ্রাঘিমাংশ:",
                        "go": "যান",
                        "churchaMine": "📍 চার্চা ভূগর্ভস্থ খনি, ছত্তিশগড় (৩০ নোড)",
                        "moonidihMine": "📍 মুনিডিহ ভূগর্ভস্থ খনি, ঝাড়খণ্ড (২৪ নোড)",
                        "vk7Mine": "📍 ভিকে৭ ভূগর্ভস্থ খনি (SCCL), তেলেঙ্গানা (২০ নোড)",
                        "raniganjBelt": "📍 রানিগঞ্জ ভূগর্ভস্থ বেল্ট, পশ্চিমবঙ্গ (১৮ নোড)",
                        "chirimiriMine": "📍 চিরিমিরি ভূগর্ভস্থ কমপ্লেক্স, ছত্তিশগড় (১৫ নোড)",
                        "nodes": "নোড:",
                        "plant": "উদ্ভিদ",
                        "clear": "পরিষ্কার করুন",
                        "nodeWord": "নোড",
                        "offlineWord": "অফলাইন",
                        "highRiskIndicators": "উচ্চ ঝুঁকি নির্দেশক",
                        "increasingDisplacement": "ক্রমবর্ধমান স্থানচ্যুতি",
                        "elevatedVibration": "উচ্চ কম্পন",
                        "highRisk": "উচ্চ ঝুঁকি",
                        "warning": "সতর্কতা",
                        "normal": "স্বাভাবিক",
                        "high": "উচ্চ",
                        "highRiskZoneDetected": "উচ্চ ঝুঁকি অঞ্চল সনাক্ত করা হয়েছে",
                        "potentialSubsidence": "সম্ভাব্য ধস কার্যকলাপ",
                        "detailedTelemetry": "বিস্তারিত টেলিমেট্রি বিশ্লেষণ",
                        "tiltX": "ঢাল (X)",
                        "tiltY": "ঢাল (Y)",
                        "displacement": "স্থানচ্যুতি",
                        "vibration": "কম্পন (RMS)",
                        "crackWidth": "ফাটলের প্রস্থ",
                        "temperature": "তাপমাত্রা",
                        "action": "কাজ",
                        "elevation": "উচ্চতা",
                        "battery": "ব্যাটারি",
                        "nodeDiagnostics": "নোড ডায়াগনস্টিকস",
                        "logCrack": "ফাটল রেকর্ড করুন"
            },
            "te": {
                        "brandName": "మైన్‌వాచ్",
                        "brandSubtitle": "గని కుంగుబాటు పర్యవేక్షణ",
                        "nodesOnline": "ఆన్‌లైన్ నోడ్లు",
                        "activeAlerts": "క్రియాశీల హెచ్చరికలు",
                        "highestRisk": "అత్యధిక ప్రమాదం",
                        "systemOperational": "సిస్టమ్ పనిచేస్తోంది",
                        "recentAlerts": "ఇటీవలి హెచ్చరికలు",
                        "nodesDirectory": "క్రమ సెన్సార్ నోడ్ల డైరెక్టరీ",
                        "nodeId": "నోడ్ ID",
                        "status": "స్థితి",
                        "lat": "అక్షాంశం:",
                        "lng": "రేఖాంశం:",
                        "go": "వెళ్ళు",
                        "churchaMine": "📍 చర్చా భూగర్భ గని, ఛత్తీస్‌గఢ్ (30 నోడ్లు)",
                        "moonidihMine": "📍 మునిడీహ్ భూగర్భ గని, జార్ఖండ్ (24 నోడ్లు)",
                        "vk7Mine": "📍 వికె7 భూగర్భ గని (SCCL), తెలంగాణ (20 నోడ్లు)",
                        "raniganjBelt": "📍 రాణిగంజ్ భూగర్భ బెల్ట్, పశ్చిమ బెంగాల్ (18 నోడ్లు)",
                        "chirimiriMine": "📍 చిరిమిరి భూగర్భ కాంప్లెక్స్, ఛత్తీస్‌గఢ్ (15 నోడ్లు)",
                        "nodes": "నోడ్లు:",
                        "plant": "నాటండి",
                        "clear": "శుభ్రం చేయండి",
                        "nodeWord": "నోడ్",
                        "offlineWord": "ఆఫ్‌లైన్",
                        "highRiskIndicators": "అధిక ప్రమాద సూచికలు",
                        "increasingDisplacement": "పెరుగుతున్న స్థానభ్రంశం",
                        "elevatedVibration": "పెరిగిన కంపనం",
                        "highRisk": "అధిక ప్రమాదం",
                        "warning": "హెచ్చరిక",
                        "normal": "సాధారణం",
                        "high": "అధిక",
                        "highRiskZoneDetected": "అధిక ప్రమాద ప్రాంతం గుర్తించబడింది",
                        "potentialSubsidence": "సంభావ్య కుంగుబాటు కార్యాచరణ",
                        "detailedTelemetry": "వివరణాత్మక టెలిమెట్రీ విశ్లేషణ",
                        "tiltX": "వంపు (X)",
                        "tiltY": "వంపు (Y)",
                        "displacement": "స్థానభ్రంశం",
                        "vibration": "కంపనం (RMS)",
                        "crackWidth": "పగుళ్ల వెడల్పు",
                        "temperature": "ఉష్ணోగ్రత",
                        "action": "చర్య",
                        "elevation": "ఎత్తు",
                        "battery": "బ్యాటరీ",
                        "nodeDiagnostics": "నోడ్ డయాగ్నోస్టిక్స్",
                        "logCrack": "పగులును నమోదు చేయండి"
            },
            "ta": {
                        "brandName": "[TA] माइनवॉच",
                        "brandSubtitle": "[TA] खदान धंसने की निगरानी",
                        "nodesOnline": "[TA] सक्रिय नोड्स",
                        "activeAlerts": "[TA] सक्रिय अलर्ट",
                        "highestRisk": "[TA] उच्चतम जोखिम",
                        "systemOperational": "[TA] प्रणाली चालू है",
                        "recentAlerts": "[TA] हाल के अलर्ट",
                        "nodesDirectory": "[TA] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[TA] नोड आईडी",
                        "status": "[TA] स्थिति",
                        "lat": "[TA] अक्षांश:",
                        "lng": "[TA] देशांतर:",
                        "go": "[TA] जाओ",
                        "churchaMine": "[TA] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[TA] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[TA] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[TA] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[TA] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[TA] नोड्स:",
                        "plant": "[TA] लगाएं",
                        "clear": "[TA] साफ़ करें",
                        "nodeWord": "[TA] नोड",
                        "offlineWord": "[TA] ऑफ़लाइन",
                        "highRiskIndicators": "[TA] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[TA] बढ़ता विस्थापन",
                        "elevatedVibration": "[TA] उच्च कंपन",
                        "highRisk": "[TA] उच्च जोखिम",
                        "warning": "[TA] चेतावनी",
                        "normal": "[TA] सामान्य",
                        "high": "[TA] उच्च",
                        "highRiskZoneDetected": "[TA] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[TA] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[TA] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[TA] झुकाव (X)",
                        "tiltY": "[TA] झुकाव (Y)",
                        "displacement": "[TA] विस्थापन",
                        "vibration": "[TA] कंपन (RMS)",
                        "crackWidth": "[TA] दरार की चौड़ाई",
                        "temperature": "[TA] तापमान",
                        "action": "[TA] कार्रवाई",
                        "elevation": "[TA] ऊंचाई",
                        "battery": "[TA] बैटरी",
                        "nodeDiagnostics": "[TA] नोड डायग्नोस्टिक्स",
                        "logCrack": "[TA] दरार दर्ज करें"
            },
            "mr": {
                        "brandName": "[MR] माइनवॉच",
                        "brandSubtitle": "[MR] खदान धंसने की निगरानी",
                        "nodesOnline": "[MR] सक्रिय नोड्स",
                        "activeAlerts": "[MR] सक्रिय अलर्ट",
                        "highestRisk": "[MR] उच्चतम जोखिम",
                        "systemOperational": "[MR] प्रणाली चालू है",
                        "recentAlerts": "[MR] हाल के अलर्ट",
                        "nodesDirectory": "[MR] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[MR] नोड आईडी",
                        "status": "[MR] स्थिति",
                        "lat": "[MR] अक्षांश:",
                        "lng": "[MR] देशांतर:",
                        "go": "[MR] जाओ",
                        "churchaMine": "[MR] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[MR] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[MR] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[MR] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[MR] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[MR] नोड्स:",
                        "plant": "[MR] लगाएं",
                        "clear": "[MR] साफ़ करें",
                        "nodeWord": "[MR] नोड",
                        "offlineWord": "[MR] ऑफ़लाइन",
                        "highRiskIndicators": "[MR] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[MR] बढ़ता विस्थापन",
                        "elevatedVibration": "[MR] उच्च कंपन",
                        "highRisk": "[MR] उच्च जोखिम",
                        "warning": "[MR] चेतावनी",
                        "normal": "[MR] सामान्य",
                        "high": "[MR] उच्च",
                        "highRiskZoneDetected": "[MR] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[MR] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[MR] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[MR] झुकाव (X)",
                        "tiltY": "[MR] झुकाव (Y)",
                        "displacement": "[MR] विस्थापन",
                        "vibration": "[MR] कंपन (RMS)",
                        "crackWidth": "[MR] दरार की चौड़ाई",
                        "temperature": "[MR] तापमान",
                        "action": "[MR] कार्रवाई",
                        "elevation": "[MR] ऊंचाई",
                        "battery": "[MR] बैटरी",
                        "nodeDiagnostics": "[MR] नोड डायग्नोस्टिक्स",
                        "logCrack": "[MR] दरार दर्ज करें"
            },
            "gu": {
                        "brandName": "[GU] माइनवॉच",
                        "brandSubtitle": "[GU] खदान धंसने की निगरानी",
                        "nodesOnline": "[GU] सक्रिय नोड्स",
                        "activeAlerts": "[GU] सक्रिय अलर्ट",
                        "highestRisk": "[GU] उच्चतम जोखिम",
                        "systemOperational": "[GU] प्रणाली चालू है",
                        "recentAlerts": "[GU] हाल के अलर्ट",
                        "nodesDirectory": "[GU] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[GU] नोड आईडी",
                        "status": "[GU] स्थिति",
                        "lat": "[GU] अक्षांश:",
                        "lng": "[GU] देशांतर:",
                        "go": "[GU] जाओ",
                        "churchaMine": "[GU] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[GU] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[GU] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[GU] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[GU] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[GU] नोड्स:",
                        "plant": "[GU] लगाएं",
                        "clear": "[GU] साफ़ करें",
                        "nodeWord": "[GU] नोड",
                        "offlineWord": "[GU] ऑफ़लाइन",
                        "highRiskIndicators": "[GU] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[GU] बढ़ता विस्थापन",
                        "elevatedVibration": "[GU] उच्च कंपन",
                        "highRisk": "[GU] उच्च जोखिम",
                        "warning": "[GU] चेतावनी",
                        "normal": "[GU] सामान्य",
                        "high": "[GU] उच्च",
                        "highRiskZoneDetected": "[GU] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[GU] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[GU] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[GU] झुकाव (X)",
                        "tiltY": "[GU] झुकाव (Y)",
                        "displacement": "[GU] विस्थापन",
                        "vibration": "[GU] कंपन (RMS)",
                        "crackWidth": "[GU] दरार की चौड़ाई",
                        "temperature": "[GU] तापमान",
                        "action": "[GU] कार्रवाई",
                        "elevation": "[GU] ऊंचाई",
                        "battery": "[GU] बैटरी",
                        "nodeDiagnostics": "[GU] नोड डायग्नोस्टिक्स",
                        "logCrack": "[GU] दरार दर्ज करें"
            },
            "ur": {
                        "brandName": "[UR] माइनवॉच",
                        "brandSubtitle": "[UR] खदान धंसने की निगरानी",
                        "nodesOnline": "[UR] सक्रिय नोड्स",
                        "activeAlerts": "[UR] सक्रिय अलर्ट",
                        "highestRisk": "[UR] उच्चतम जोखिम",
                        "systemOperational": "[UR] प्रणाली चालू है",
                        "recentAlerts": "[UR] हाल के अलर्ट",
                        "nodesDirectory": "[UR] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[UR] नोड आईडी",
                        "status": "[UR] स्थिति",
                        "lat": "[UR] अक्षांश:",
                        "lng": "[UR] देशांतर:",
                        "go": "[UR] जाओ",
                        "churchaMine": "[UR] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[UR] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[UR] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[UR] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[UR] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[UR] नोड्स:",
                        "plant": "[UR] लगाएं",
                        "clear": "[UR] साफ़ करें",
                        "nodeWord": "[UR] नोड",
                        "offlineWord": "[UR] ऑफ़लाइन",
                        "highRiskIndicators": "[UR] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[UR] बढ़ता विस्थापन",
                        "elevatedVibration": "[UR] उच्च कंपन",
                        "highRisk": "[UR] उच्च जोखिम",
                        "warning": "[UR] चेतावनी",
                        "normal": "[UR] सामान्य",
                        "high": "[UR] उच्च",
                        "highRiskZoneDetected": "[UR] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[UR] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[UR] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[UR] झुकाव (X)",
                        "tiltY": "[UR] झुकाव (Y)",
                        "displacement": "[UR] विस्थापन",
                        "vibration": "[UR] कंपन (RMS)",
                        "crackWidth": "[UR] दरार की चौड़ाई",
                        "temperature": "[UR] तापमान",
                        "action": "[UR] कार्रवाई",
                        "elevation": "[UR] ऊंचाई",
                        "battery": "[UR] बैटरी",
                        "nodeDiagnostics": "[UR] नोड डायग्नोस्टिक्स",
                        "logCrack": "[UR] दरार दर्ज करें"
            },
            "kn": {
                        "brandName": "[KN] माइनवॉच",
                        "brandSubtitle": "[KN] खदान धंसने की निगरानी",
                        "nodesOnline": "[KN] सक्रिय नोड्स",
                        "activeAlerts": "[KN] सक्रिय अलर्ट",
                        "highestRisk": "[KN] उच्चतम जोखिम",
                        "systemOperational": "[KN] प्रणाली चालू है",
                        "recentAlerts": "[KN] हाल के अलर्ट",
                        "nodesDirectory": "[KN] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[KN] नोड आईडी",
                        "status": "[KN] स्थिति",
                        "lat": "[KN] अक्षांश:",
                        "lng": "[KN] देशांतर:",
                        "go": "[KN] जाओ",
                        "churchaMine": "[KN] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[KN] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[KN] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[KN] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[KN] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[KN] नोड्स:",
                        "plant": "[KN] लगाएं",
                        "clear": "[KN] साफ़ करें",
                        "nodeWord": "[KN] नोड",
                        "offlineWord": "[KN] ऑफ़लाइन",
                        "highRiskIndicators": "[KN] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[KN] बढ़ता विस्थापन",
                        "elevatedVibration": "[KN] उच्च कंपन",
                        "highRisk": "[KN] उच्च जोखिम",
                        "warning": "[KN] चेतावनी",
                        "normal": "[KN] सामान्य",
                        "high": "[KN] उच्च",
                        "highRiskZoneDetected": "[KN] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[KN] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[KN] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[KN] झुकाव (X)",
                        "tiltY": "[KN] झुकाव (Y)",
                        "displacement": "[KN] विस्थापन",
                        "vibration": "[KN] कंपन (RMS)",
                        "crackWidth": "[KN] दरार की चौड़ाई",
                        "temperature": "[KN] तापमान",
                        "action": "[KN] कार्रवाई",
                        "elevation": "[KN] ऊंचाई",
                        "battery": "[KN] बैटरी",
                        "nodeDiagnostics": "[KN] नोड डायग्नोस्टिक्स",
                        "logCrack": "[KN] दरार दर्ज करें"
            },
            "ml": {
                        "brandName": "[ML] माइनवॉच",
                        "brandSubtitle": "[ML] खदान धंसने की निगरानी",
                        "nodesOnline": "[ML] सक्रिय नोड्स",
                        "activeAlerts": "[ML] सक्रिय अलर्ट",
                        "highestRisk": "[ML] उच्चतम जोखिम",
                        "systemOperational": "[ML] प्रणाली चालू है",
                        "recentAlerts": "[ML] हाल के अलर्ट",
                        "nodesDirectory": "[ML] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[ML] नोड आईडी",
                        "status": "[ML] स्थिति",
                        "lat": "[ML] अक्षांश:",
                        "lng": "[ML] देशांतर:",
                        "go": "[ML] जाओ",
                        "churchaMine": "[ML] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[ML] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[ML] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[ML] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[ML] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[ML] नोड्स:",
                        "plant": "[ML] लगाएं",
                        "clear": "[ML] साफ़ करें",
                        "nodeWord": "[ML] नोड",
                        "offlineWord": "[ML] ऑफ़लाइन",
                        "highRiskIndicators": "[ML] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[ML] बढ़ता विस्थापन",
                        "elevatedVibration": "[ML] उच्च कंपन",
                        "highRisk": "[ML] उच्च जोखिम",
                        "warning": "[ML] चेतावनी",
                        "normal": "[ML] सामान्य",
                        "high": "[ML] उच्च",
                        "highRiskZoneDetected": "[ML] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[ML] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[ML] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[ML] झुकाव (X)",
                        "tiltY": "[ML] झुकाव (Y)",
                        "displacement": "[ML] विस्थापन",
                        "vibration": "[ML] कंपन (RMS)",
                        "crackWidth": "[ML] दरार की चौड़ाई",
                        "temperature": "[ML] तापमान",
                        "action": "[ML] कार्रवाई",
                        "elevation": "[ML] ऊंचाई",
                        "battery": "[ML] बैटरी",
                        "nodeDiagnostics": "[ML] नोड डायग्नोस्टिक्स",
                        "logCrack": "[ML] दरार दर्ज करें"
            },
            "pa": {
                        "brandName": "[PA] माइनवॉच",
                        "brandSubtitle": "[PA] खदान धंसने की निगरानी",
                        "nodesOnline": "[PA] सक्रिय नोड्स",
                        "activeAlerts": "[PA] सक्रिय अलर्ट",
                        "highestRisk": "[PA] उच्चतम जोखिम",
                        "systemOperational": "[PA] प्रणाली चालू है",
                        "recentAlerts": "[PA] हाल के अलर्ट",
                        "nodesDirectory": "[PA] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[PA] नोड आईडी",
                        "status": "[PA] स्थिति",
                        "lat": "[PA] अक्षांश:",
                        "lng": "[PA] देशांतर:",
                        "go": "[PA] जाओ",
                        "churchaMine": "[PA] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[PA] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[PA] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[PA] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[PA] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[PA] नोड्स:",
                        "plant": "[PA] लगाएं",
                        "clear": "[PA] साफ़ करें",
                        "nodeWord": "[PA] नोड",
                        "offlineWord": "[PA] ऑफ़लाइन",
                        "highRiskIndicators": "[PA] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[PA] बढ़ता विस्थापन",
                        "elevatedVibration": "[PA] उच्च कंपन",
                        "highRisk": "[PA] उच्च जोखिम",
                        "warning": "[PA] चेतावनी",
                        "normal": "[PA] सामान्य",
                        "high": "[PA] उच्च",
                        "highRiskZoneDetected": "[PA] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[PA] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[PA] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[PA] झुकाव (X)",
                        "tiltY": "[PA] झुकाव (Y)",
                        "displacement": "[PA] विस्थापन",
                        "vibration": "[PA] कंपन (RMS)",
                        "crackWidth": "[PA] दरार की चौड़ाई",
                        "temperature": "[PA] तापमान",
                        "action": "[PA] कार्रवाई",
                        "elevation": "[PA] ऊंचाई",
                        "battery": "[PA] बैटरी",
                        "nodeDiagnostics": "[PA] नोड डायग्नोस्टिक्स",
                        "logCrack": "[PA] दरार दर्ज करें"
            },
            "as": {
                        "brandName": "[AS] माइनवॉच",
                        "brandSubtitle": "[AS] खदान धंसने की निगरानी",
                        "nodesOnline": "[AS] सक्रिय नोड्स",
                        "activeAlerts": "[AS] सक्रिय अलर्ट",
                        "highestRisk": "[AS] उच्चतम जोखिम",
                        "systemOperational": "[AS] प्रणाली चालू है",
                        "recentAlerts": "[AS] हाल के अलर्ट",
                        "nodesDirectory": "[AS] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[AS] नोड आईडी",
                        "status": "[AS] स्थिति",
                        "lat": "[AS] अक्षांश:",
                        "lng": "[AS] देशांतर:",
                        "go": "[AS] जाओ",
                        "churchaMine": "[AS] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[AS] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[AS] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[AS] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[AS] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[AS] नोड्स:",
                        "plant": "[AS] लगाएं",
                        "clear": "[AS] साफ़ करें",
                        "nodeWord": "[AS] नोड",
                        "offlineWord": "[AS] ऑफ़लाइन",
                        "highRiskIndicators": "[AS] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[AS] बढ़ता विस्थापन",
                        "elevatedVibration": "[AS] उच्च कंपन",
                        "highRisk": "[AS] उच्च जोखिम",
                        "warning": "[AS] चेतावनी",
                        "normal": "[AS] सामान्य",
                        "high": "[AS] उच्च",
                        "highRiskZoneDetected": "[AS] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[AS] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[AS] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[AS] झुकाव (X)",
                        "tiltY": "[AS] झुकाव (Y)",
                        "displacement": "[AS] विस्थापन",
                        "vibration": "[AS] कंपन (RMS)",
                        "crackWidth": "[AS] दरार की चौड़ाई",
                        "temperature": "[AS] तापमान",
                        "action": "[AS] कार्रवाई",
                        "elevation": "[AS] ऊंचाई",
                        "battery": "[AS] बैटरी",
                        "nodeDiagnostics": "[AS] नोड डायग्नोस्टिक्स",
                        "logCrack": "[AS] दरार दर्ज करें"
            },
            "mai": {
                        "brandName": "[MAI] माइनवॉच",
                        "brandSubtitle": "[MAI] खदान धंसने की निगरानी",
                        "nodesOnline": "[MAI] सक्रिय नोड्स",
                        "activeAlerts": "[MAI] सक्रिय अलर्ट",
                        "highestRisk": "[MAI] उच्चतम जोखिम",
                        "systemOperational": "[MAI] प्रणाली चालू है",
                        "recentAlerts": "[MAI] हाल के अलर्ट",
                        "nodesDirectory": "[MAI] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[MAI] नोड आईडी",
                        "status": "[MAI] स्थिति",
                        "lat": "[MAI] अक्षांश:",
                        "lng": "[MAI] देशांतर:",
                        "go": "[MAI] जाओ",
                        "churchaMine": "[MAI] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[MAI] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[MAI] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[MAI] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[MAI] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[MAI] नोड्स:",
                        "plant": "[MAI] लगाएं",
                        "clear": "[MAI] साफ़ करें",
                        "nodeWord": "[MAI] नोड",
                        "offlineWord": "[MAI] ऑफ़लाइन",
                        "highRiskIndicators": "[MAI] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[MAI] बढ़ता विस्थापन",
                        "elevatedVibration": "[MAI] उच्च कंपन",
                        "highRisk": "[MAI] उच्च जोखिम",
                        "warning": "[MAI] चेतावनी",
                        "normal": "[MAI] सामान्य",
                        "high": "[MAI] उच्च",
                        "highRiskZoneDetected": "[MAI] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[MAI] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[MAI] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[MAI] झुकाव (X)",
                        "tiltY": "[MAI] झुकाव (Y)",
                        "displacement": "[MAI] विस्थापन",
                        "vibration": "[MAI] कंपन (RMS)",
                        "crackWidth": "[MAI] दरार की चौड़ाई",
                        "temperature": "[MAI] तापमान",
                        "action": "[MAI] कार्रवाई",
                        "elevation": "[MAI] ऊंचाई",
                        "battery": "[MAI] बैटरी",
                        "nodeDiagnostics": "[MAI] नोड डायग्नोस्टिक्स",
                        "logCrack": "[MAI] दरार दर्ज करें"
            },
            "sat": {
                        "brandName": "[SAT] माइनवॉच",
                        "brandSubtitle": "[SAT] खदान धंसने की निगरानी",
                        "nodesOnline": "[SAT] सक्रिय नोड्स",
                        "activeAlerts": "[SAT] सक्रिय अलर्ट",
                        "highestRisk": "[SAT] उच्चतम जोखिम",
                        "systemOperational": "[SAT] प्रणाली चालू है",
                        "recentAlerts": "[SAT] हाल के अलर्ट",
                        "nodesDirectory": "[SAT] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[SAT] नोड आईडी",
                        "status": "[SAT] स्थिति",
                        "lat": "[SAT] अक्षांश:",
                        "lng": "[SAT] देशांतर:",
                        "go": "[SAT] जाओ",
                        "churchaMine": "[SAT] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[SAT] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[SAT] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[SAT] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[SAT] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[SAT] नोड्स:",
                        "plant": "[SAT] लगाएं",
                        "clear": "[SAT] साफ़ करें",
                        "nodeWord": "[SAT] नोड",
                        "offlineWord": "[SAT] ऑफ़लाइन",
                        "highRiskIndicators": "[SAT] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[SAT] बढ़ता विस्थापन",
                        "elevatedVibration": "[SAT] उच्च कंपन",
                        "highRisk": "[SAT] उच्च जोखिम",
                        "warning": "[SAT] चेतावनी",
                        "normal": "[SAT] सामान्य",
                        "high": "[SAT] उच्च",
                        "highRiskZoneDetected": "[SAT] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[SAT] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[SAT] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[SAT] झुकाव (X)",
                        "tiltY": "[SAT] झुकाव (Y)",
                        "displacement": "[SAT] विस्थापन",
                        "vibration": "[SAT] कंपन (RMS)",
                        "crackWidth": "[SAT] दरार की चौड़ाई",
                        "temperature": "[SAT] तापमान",
                        "action": "[SAT] कार्रवाई",
                        "elevation": "[SAT] ऊंचाई",
                        "battery": "[SAT] बैटरी",
                        "nodeDiagnostics": "[SAT] नोड डायग्नोस्टिक्स",
                        "logCrack": "[SAT] दरार दर्ज करें"
            },
            "ks": {
                        "brandName": "[KS] माइनवॉच",
                        "brandSubtitle": "[KS] खदान धंसने की निगरानी",
                        "nodesOnline": "[KS] सक्रिय नोड्स",
                        "activeAlerts": "[KS] सक्रिय अलर्ट",
                        "highestRisk": "[KS] उच्चतम जोखिम",
                        "systemOperational": "[KS] प्रणाली चालू है",
                        "recentAlerts": "[KS] हाल के अलर्ट",
                        "nodesDirectory": "[KS] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[KS] नोड आईडी",
                        "status": "[KS] स्थिति",
                        "lat": "[KS] अक्षांश:",
                        "lng": "[KS] देशांतर:",
                        "go": "[KS] जाओ",
                        "churchaMine": "[KS] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[KS] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[KS] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[KS] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[KS] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[KS] नोड्स:",
                        "plant": "[KS] लगाएं",
                        "clear": "[KS] साफ़ करें",
                        "nodeWord": "[KS] नोड",
                        "offlineWord": "[KS] ऑफ़लाइन",
                        "highRiskIndicators": "[KS] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[KS] बढ़ता विस्थापन",
                        "elevatedVibration": "[KS] उच्च कंपन",
                        "highRisk": "[KS] उच्च जोखिम",
                        "warning": "[KS] चेतावनी",
                        "normal": "[KS] सामान्य",
                        "high": "[KS] उच्च",
                        "highRiskZoneDetected": "[KS] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[KS] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[KS] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[KS] झुकाव (X)",
                        "tiltY": "[KS] झुकाव (Y)",
                        "displacement": "[KS] विस्थापन",
                        "vibration": "[KS] कंपन (RMS)",
                        "crackWidth": "[KS] दरार की चौड़ाई",
                        "temperature": "[KS] तापमान",
                        "action": "[KS] कार्रवाई",
                        "elevation": "[KS] ऊंचाई",
                        "battery": "[KS] बैटरी",
                        "nodeDiagnostics": "[KS] नोड डायग्नोस्टिक्स",
                        "logCrack": "[KS] दरार दर्ज करें"
            },
            "ne": {
                        "brandName": "[NE] माइनवॉच",
                        "brandSubtitle": "[NE] खदान धंसने की निगरानी",
                        "nodesOnline": "[NE] सक्रिय नोड्स",
                        "activeAlerts": "[NE] सक्रिय अलर्ट",
                        "highestRisk": "[NE] उच्चतम जोखिम",
                        "systemOperational": "[NE] प्रणाली चालू है",
                        "recentAlerts": "[NE] हाल के अलर्ट",
                        "nodesDirectory": "[NE] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[NE] नोड आईडी",
                        "status": "[NE] स्थिति",
                        "lat": "[NE] अक्षांश:",
                        "lng": "[NE] देशांतर:",
                        "go": "[NE] जाओ",
                        "churchaMine": "[NE] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[NE] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[NE] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[NE] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[NE] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[NE] नोड्स:",
                        "plant": "[NE] लगाएं",
                        "clear": "[NE] साफ़ करें",
                        "nodeWord": "[NE] नोड",
                        "offlineWord": "[NE] ऑफ़लाइन",
                        "highRiskIndicators": "[NE] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[NE] बढ़ता विस्थापन",
                        "elevatedVibration": "[NE] उच्च कंपन",
                        "highRisk": "[NE] उच्च जोखिम",
                        "warning": "[NE] चेतावनी",
                        "normal": "[NE] सामान्य",
                        "high": "[NE] उच्च",
                        "highRiskZoneDetected": "[NE] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[NE] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[NE] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[NE] झुकाव (X)",
                        "tiltY": "[NE] झुकाव (Y)",
                        "displacement": "[NE] विस्थापन",
                        "vibration": "[NE] कंपन (RMS)",
                        "crackWidth": "[NE] दरार की चौड़ाई",
                        "temperature": "[NE] तापमान",
                        "action": "[NE] कार्रवाई",
                        "elevation": "[NE] ऊंचाई",
                        "battery": "[NE] बैटरी",
                        "nodeDiagnostics": "[NE] नोड डायग्नोस्टिक्स",
                        "logCrack": "[NE] दरार दर्ज करें"
            },
            "kok": {
                        "brandName": "[KOK] माइनवॉच",
                        "brandSubtitle": "[KOK] खदान धंसने की निगरानी",
                        "nodesOnline": "[KOK] सक्रिय नोड्स",
                        "activeAlerts": "[KOK] सक्रिय अलर्ट",
                        "highestRisk": "[KOK] उच्चतम जोखिम",
                        "systemOperational": "[KOK] प्रणाली चालू है",
                        "recentAlerts": "[KOK] हाल के अलर्ट",
                        "nodesDirectory": "[KOK] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[KOK] नोड आईडी",
                        "status": "[KOK] स्थिति",
                        "lat": "[KOK] अक्षांश:",
                        "lng": "[KOK] देशांतर:",
                        "go": "[KOK] जाओ",
                        "churchaMine": "[KOK] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[KOK] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[KOK] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[KOK] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[KOK] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[KOK] नोड्स:",
                        "plant": "[KOK] लगाएं",
                        "clear": "[KOK] साफ़ करें",
                        "nodeWord": "[KOK] नोड",
                        "offlineWord": "[KOK] ऑफ़लाइन",
                        "highRiskIndicators": "[KOK] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[KOK] बढ़ता विस्थापन",
                        "elevatedVibration": "[KOK] उच्च कंपन",
                        "highRisk": "[KOK] उच्च जोखिम",
                        "warning": "[KOK] चेतावनी",
                        "normal": "[KOK] सामान्य",
                        "high": "[KOK] उच्च",
                        "highRiskZoneDetected": "[KOK] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[KOK] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[KOK] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[KOK] झुकाव (X)",
                        "tiltY": "[KOK] झुकाव (Y)",
                        "displacement": "[KOK] विस्थापन",
                        "vibration": "[KOK] कंपन (RMS)",
                        "crackWidth": "[KOK] दरार की चौड़ाई",
                        "temperature": "[KOK] तापमान",
                        "action": "[KOK] कार्रवाई",
                        "elevation": "[KOK] ऊंचाई",
                        "battery": "[KOK] बैटरी",
                        "nodeDiagnostics": "[KOK] नोड डायग्नोस्टिक्स",
                        "logCrack": "[KOK] दरार दर्ज करें"
            },
            "sd": {
                        "brandName": "[SD] माइनवॉच",
                        "brandSubtitle": "[SD] खदान धंसने की निगरानी",
                        "nodesOnline": "[SD] सक्रिय नोड्स",
                        "activeAlerts": "[SD] सक्रिय अलर्ट",
                        "highestRisk": "[SD] उच्चतम जोखिम",
                        "systemOperational": "[SD] प्रणाली चालू है",
                        "recentAlerts": "[SD] हाल के अलर्ट",
                        "nodesDirectory": "[SD] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[SD] नोड आईडी",
                        "status": "[SD] स्थिति",
                        "lat": "[SD] अक्षांश:",
                        "lng": "[SD] देशांतर:",
                        "go": "[SD] जाओ",
                        "churchaMine": "[SD] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[SD] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[SD] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[SD] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[SD] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[SD] नोड्स:",
                        "plant": "[SD] लगाएं",
                        "clear": "[SD] साफ़ करें",
                        "nodeWord": "[SD] नोड",
                        "offlineWord": "[SD] ऑफ़लाइन",
                        "highRiskIndicators": "[SD] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[SD] बढ़ता विस्थापन",
                        "elevatedVibration": "[SD] उच्च कंपन",
                        "highRisk": "[SD] उच्च जोखिम",
                        "warning": "[SD] चेतावनी",
                        "normal": "[SD] सामान्य",
                        "high": "[SD] उच्च",
                        "highRiskZoneDetected": "[SD] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[SD] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[SD] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[SD] झुकाव (X)",
                        "tiltY": "[SD] झुकाव (Y)",
                        "displacement": "[SD] विस्थापन",
                        "vibration": "[SD] कंपन (RMS)",
                        "crackWidth": "[SD] दरार की चौड़ाई",
                        "temperature": "[SD] तापमान",
                        "action": "[SD] कार्रवाई",
                        "elevation": "[SD] ऊंचाई",
                        "battery": "[SD] बैटरी",
                        "nodeDiagnostics": "[SD] नोड डायग्नोस्टिक्स",
                        "logCrack": "[SD] दरार दर्ज करें"
            },
            "doi": {
                        "brandName": "[DOI] माइनवॉच",
                        "brandSubtitle": "[DOI] खदान धंसने की निगरानी",
                        "nodesOnline": "[DOI] सक्रिय नोड्स",
                        "activeAlerts": "[DOI] सक्रिय अलर्ट",
                        "highestRisk": "[DOI] उच्चतम जोखिम",
                        "systemOperational": "[DOI] प्रणाली चालू है",
                        "recentAlerts": "[DOI] हाल के अलर्ट",
                        "nodesDirectory": "[DOI] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[DOI] नोड आईडी",
                        "status": "[DOI] स्थिति",
                        "lat": "[DOI] अक्षांश:",
                        "lng": "[DOI] देशांतर:",
                        "go": "[DOI] जाओ",
                        "churchaMine": "[DOI] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[DOI] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[DOI] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[DOI] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[DOI] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[DOI] नोड्स:",
                        "plant": "[DOI] लगाएं",
                        "clear": "[DOI] साफ़ करें",
                        "nodeWord": "[DOI] नोड",
                        "offlineWord": "[DOI] ऑफ़लाइन",
                        "highRiskIndicators": "[DOI] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[DOI] बढ़ता विस्थापन",
                        "elevatedVibration": "[DOI] उच्च कंपन",
                        "highRisk": "[DOI] उच्च जोखिम",
                        "warning": "[DOI] चेतावनी",
                        "normal": "[DOI] सामान्य",
                        "high": "[DOI] उच्च",
                        "highRiskZoneDetected": "[DOI] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[DOI] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[DOI] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[DOI] झुकाव (X)",
                        "tiltY": "[DOI] झुकाव (Y)",
                        "displacement": "[DOI] विस्थापन",
                        "vibration": "[DOI] कंपन (RMS)",
                        "crackWidth": "[DOI] दरार की चौड़ाई",
                        "temperature": "[DOI] तापमान",
                        "action": "[DOI] कार्रवाई",
                        "elevation": "[DOI] ऊंचाई",
                        "battery": "[DOI] बैटरी",
                        "nodeDiagnostics": "[DOI] नोड डायग्नोस्टिक्स",
                        "logCrack": "[DOI] दरार दर्ज करें"
            },
            "mni": {
                        "brandName": "[MNI] माइनवॉच",
                        "brandSubtitle": "[MNI] खदान धंसने की निगरानी",
                        "nodesOnline": "[MNI] सक्रिय नोड्स",
                        "activeAlerts": "[MNI] सक्रिय अलर्ट",
                        "highestRisk": "[MNI] उच्चतम जोखिम",
                        "systemOperational": "[MNI] प्रणाली चालू है",
                        "recentAlerts": "[MNI] हाल के अलर्ट",
                        "nodesDirectory": "[MNI] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[MNI] नोड आईडी",
                        "status": "[MNI] स्थिति",
                        "lat": "[MNI] अक्षांश:",
                        "lng": "[MNI] देशांतर:",
                        "go": "[MNI] जाओ",
                        "churchaMine": "[MNI] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[MNI] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[MNI] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[MNI] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[MNI] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[MNI] नोड्स:",
                        "plant": "[MNI] लगाएं",
                        "clear": "[MNI] साफ़ करें",
                        "nodeWord": "[MNI] नोड",
                        "offlineWord": "[MNI] ऑफ़लाइन",
                        "highRiskIndicators": "[MNI] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[MNI] बढ़ता विस्थापन",
                        "elevatedVibration": "[MNI] उच्च कंपन",
                        "highRisk": "[MNI] उच्च जोखिम",
                        "warning": "[MNI] चेतावनी",
                        "normal": "[MNI] सामान्य",
                        "high": "[MNI] उच्च",
                        "highRiskZoneDetected": "[MNI] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[MNI] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[MNI] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[MNI] झुकाव (X)",
                        "tiltY": "[MNI] झुकाव (Y)",
                        "displacement": "[MNI] विस्थापन",
                        "vibration": "[MNI] कंपन (RMS)",
                        "crackWidth": "[MNI] दरार की चौड़ाई",
                        "temperature": "[MNI] तापमान",
                        "action": "[MNI] कार्रवाई",
                        "elevation": "[MNI] ऊंचाई",
                        "battery": "[MNI] बैटरी",
                        "nodeDiagnostics": "[MNI] नोड डायग्नोस्टिक्स",
                        "logCrack": "[MNI] दरार दर्ज करें"
            },
            "brx": {
                        "brandName": "[BRX] माइनवॉच",
                        "brandSubtitle": "[BRX] खदान धंसने की निगरानी",
                        "nodesOnline": "[BRX] सक्रिय नोड्स",
                        "activeAlerts": "[BRX] सक्रिय अलर्ट",
                        "highestRisk": "[BRX] उच्चतम जोखिम",
                        "systemOperational": "[BRX] प्रणाली चालू है",
                        "recentAlerts": "[BRX] हाल के अलर्ट",
                        "nodesDirectory": "[BRX] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[BRX] नोड आईडी",
                        "status": "[BRX] स्थिति",
                        "lat": "[BRX] अक्षांश:",
                        "lng": "[BRX] देशांतर:",
                        "go": "[BRX] जाओ",
                        "churchaMine": "[BRX] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[BRX] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[BRX] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[BRX] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[BRX] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[BRX] नोड्स:",
                        "plant": "[BRX] लगाएं",
                        "clear": "[BRX] साफ़ करें",
                        "nodeWord": "[BRX] नोड",
                        "offlineWord": "[BRX] ऑफ़लाइन",
                        "highRiskIndicators": "[BRX] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[BRX] बढ़ता विस्थापन",
                        "elevatedVibration": "[BRX] उच्च कंपन",
                        "highRisk": "[BRX] उच्च जोखिम",
                        "warning": "[BRX] चेतावनी",
                        "normal": "[BRX] सामान्य",
                        "high": "[BRX] उच्च",
                        "highRiskZoneDetected": "[BRX] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[BRX] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[BRX] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[BRX] झुकाव (X)",
                        "tiltY": "[BRX] झुकाव (Y)",
                        "displacement": "[BRX] विस्थापन",
                        "vibration": "[BRX] कंपन (RMS)",
                        "crackWidth": "[BRX] दरार की चौड़ाई",
                        "temperature": "[BRX] तापमान",
                        "action": "[BRX] कार्रवाई",
                        "elevation": "[BRX] ऊंचाई",
                        "battery": "[BRX] बैटरी",
                        "nodeDiagnostics": "[BRX] नोड डायग्नोस्टिक्स",
                        "logCrack": "[BRX] दरार दर्ज करें"
            },
            "sa": {
                        "brandName": "[SA] माइनवॉच",
                        "brandSubtitle": "[SA] खदान धंसने की निगरानी",
                        "nodesOnline": "[SA] सक्रिय नोड्स",
                        "activeAlerts": "[SA] सक्रिय अलर्ट",
                        "highestRisk": "[SA] उच्चतम जोखिम",
                        "systemOperational": "[SA] प्रणाली चालू है",
                        "recentAlerts": "[SA] हाल के अलर्ट",
                        "nodesDirectory": "[SA] क्रमिक सेंसर नोड्स निर्देशिका",
                        "nodeId": "[SA] नोड आईडी",
                        "status": "[SA] स्थिति",
                        "lat": "[SA] अक्षांश:",
                        "lng": "[SA] देशांतर:",
                        "go": "[SA] जाओ",
                        "churchaMine": "[SA] 📍 चर्चा भूमिगत खदान, छत्तीसगढ़ (30 नोड)",
                        "moonidihMine": "[SA] 📍 मुनिडीह भूमिगत खदान, झारखंड (24 नोड)",
                        "vk7Mine": "[SA] 📍 वीके7 भूमिगत खदान (एससीसीएल), तेलंगाना (20 नोड)",
                        "raniganjBelt": "[SA] 📍 रानीगंज भूमिगत बेल्ट, पश्चिम बंगाल (18 नोड)",
                        "chirimiriMine": "[SA] 📍 चिरमिरी भूमिगत परिसर, छत्तीसगढ़ (15 नोड)",
                        "nodes": "[SA] नोड्स:",
                        "plant": "[SA] लगाएं",
                        "clear": "[SA] साफ़ करें",
                        "nodeWord": "[SA] नोड",
                        "offlineWord": "[SA] ऑफ़लाइन",
                        "highRiskIndicators": "[SA] उच्च जोखिम संकेतक",
                        "increasingDisplacement": "[SA] बढ़ता विस्थापन",
                        "elevatedVibration": "[SA] उच्च कंपन",
                        "highRisk": "[SA] उच्च जोखिम",
                        "warning": "[SA] चेतावनी",
                        "normal": "[SA] सामान्य",
                        "high": "[SA] उच्च",
                        "highRiskZoneDetected": "[SA] उच्च जोखिम क्षेत्र का पता चला",
                        "potentialSubsidence": "[SA] संभावित धंसाव गतिविधि",
                        "detailedTelemetry": "[SA] विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट",
                        "tiltX": "[SA] झुकाव (X)",
                        "tiltY": "[SA] झुकाव (Y)",
                        "displacement": "[SA] विस्थापन",
                        "vibration": "[SA] कंपन (RMS)",
                        "crackWidth": "[SA] दरार की चौड़ाई",
                        "temperature": "[SA] तापमान",
                        "action": "[SA] कार्रवाई",
                        "elevation": "[SA] ऊंचाई",
                        "battery": "[SA] बैटरी",
                        "nodeDiagnostics": "[SA] नोड डायग्नोस्टिक्स",
                        "logCrack": "[SA] दरार दर्ज करें"
            }
};

        langSelect.addEventListener('change', (e) => {
            const lang = e.target.value;
            const dict = translations[lang] || {}; // fallback to empty for english (relying on original text is tricky without a full dictionary, we'll just mock it for Hindi as requested)
            
            document.querySelectorAll('[data-i18n]').forEach(el => {
                const key = el.getAttribute('data-i18n');
                if (dict[key]) {
                    el.dataset.original = el.dataset.original || el.textContent;
                    el.textContent = dict[key];
                } else if (el.dataset.original) {
                    el.textContent = el.dataset.original;
                }
            });
        });
    }

    // ==========================================================================
    // SYSTEM DIAGNOSIS & NODE DEBUGGING SUITE (ASUS-Style Hardware Diagnostics)
    // ==========================================================================
    let currentDiagNodeId = 'N16';
    let diagTestInterval = null;

    window.openNodeDiagnosticsModal = function(nodeId) {
        if (!nodeId) {
            nodeId = selectedNodeId || (activeNodesList.length > 0 ? activeNodesList[0].id : 'N16');
        }
        currentDiagNodeId = nodeId;

        const modalOverlay = document.getElementById('diagnostics-modal-overlay');
        const nodeSelect = document.getElementById('diag-node-select');
        const customNodeName = document.getElementById('diag-custom-node-name');
        
        if (nodeSelect) {
            nodeSelect.innerHTML = '';
            activeNodesList.forEach(n => {
                const opt = document.createElement('option');
                opt.value = n.id;
                opt.textContent = `Node ${n.id} (${n.status.toUpperCase()})`;
                if (n.id === currentDiagNodeId) opt.selected = true;
                nodeSelect.appendChild(opt);
            });
        }

        if (customNodeName) {
            customNodeName.textContent = `Node ${currentDiagNodeId}`;
        }

        // Reset live test panel
        const testPanel = document.getElementById('diag-test-live-panel');
        if (testPanel) testPanel.style.display = 'none';

        // Update last checked timestamp
        const now = new Date();
        const timeStr = `${now.getFullYear()}/${String(now.getMonth()+1).padStart(2,'0')}/${String(now.getDate()).padStart(2,'0')} ${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}:${String(now.getSeconds()).padStart(2,'0')}`;
        const lastCheckedEl = document.getElementById('diag-last-checked-time');
        if (lastCheckedEl) lastCheckedEl.textContent = timeStr;

        switchDiagTab('tool');
        updateDiagDebugMetrics(currentDiagNodeId);

        if (modalOverlay) {
            modalOverlay.style.display = 'flex';
        }
    };

    window.closeNodeDiagnosticsModal = function() {
        const modalOverlay = document.getElementById('diagnostics-modal-overlay');
        if (modalOverlay) {
            modalOverlay.style.display = 'none';
        }
        if (diagTestInterval) {
            clearInterval(diagTestInterval);
            diagTestInterval = null;
        }
    };

    window.onDiagNodeSelectChange = function(nodeId) {
        currentDiagNodeId = nodeId;
        const customNodeName = document.getElementById('diag-custom-node-name');
        if (customNodeName) customNodeName.textContent = `Node ${currentDiagNodeId}`;
        
        // Hide live test if running for previous node
        const testPanel = document.getElementById('diag-test-live-panel');
        if (testPanel) testPanel.style.display = 'none';

        updateDiagDebugMetrics(currentDiagNodeId);
    };

    window.switchDiagTab = function(tab) {
        const toolBtn = document.getElementById('diag-tab-tool-btn');
        const histBtn = document.getElementById('diag-tab-history-btn');
        const toolContent = document.getElementById('diag-tab-tool-content');
        const histContent = document.getElementById('diag-tab-history-content');

        if (tab === 'tool') {
            if (toolBtn) toolBtn.classList.add('active');
            if (histBtn) histBtn.classList.remove('active');
            if (toolContent) toolContent.style.display = 'block';
            if (histContent) histContent.style.display = 'none';
        } else {
            if (histBtn) histBtn.classList.add('active');
            if (toolBtn) toolBtn.classList.remove('active');
            if (histContent) histContent.style.display = 'block';
            if (toolContent) toolContent.style.display = 'none';
        }
    };

    window.toggleDiagCheckboxes = function(type, checked) {
        if (type === 'auto') {
            document.querySelectorAll('.cb-auto').forEach(cb => cb.checked = checked);
        } else if (type === 'inter') {
            document.querySelectorAll('.cb-inter').forEach(cb => cb.checked = checked);
        }
    };

    function updateDiagDebugMetrics(nodeId) {
        const node = activeNodesList.find(n => n.id === nodeId) || activeNodesList[0] || { bat: 85, tiltX: 0.42, tiltY: 0.31, vib: 0.08, temp: 28.6, status: 'normal' };
        
        const batV = (3.3 + (node.bat / 100) * 0.9).toFixed(2);
        const soh = node.bat > 50 ? '98% (Optimal)' : node.bat > 20 ? '82% (Good)' : '45% (Degraded)';
        
        const dbgBatV = document.getElementById('dbg-bat-v');
        const dbgBatSoc = document.getElementById('dbg-bat-soc');
        const dbgBatSoh = document.getElementById('dbg-bat-soh');
        const dbgSolarV = document.getElementById('dbg-solar-v');
        const dbgCurrDraw = document.getElementById('dbg-curr-draw');
        
        const dbgTiltX = document.getElementById('dbg-tilt-x');
        const dbgTiltY = document.getElementById('dbg-tilt-y');
        const dbgZeroOffset = document.getElementById('dbg-zero-offset');
        const dbgVibRms = document.getElementById('dbg-vib-rms');
        const dbgPcbTemp = document.getElementById('dbg-pcb-temp');
        
        const dbgRssi = document.getElementById('dbg-rssi');
        const dbgSnr = document.getElementById('dbg-snr');
        const dbgPdr = document.getElementById('dbg-pdr');

        if (dbgBatV) dbgBatV.textContent = `${batV} V`;
        if (dbgBatSoc) dbgBatSoc.textContent = `${node.bat}%`;
        if (dbgBatSoh) dbgBatSoh.textContent = soh;
        if (dbgSolarV) dbgSolarV.textContent = node.bat < 95 ? '5.12 V / 140 mA (Charging)' : '5.05 V / 10 mA (Float)';
        if (dbgCurrDraw) dbgCurrDraw.textContent = `${(11.5 + Math.random() * 2).toFixed(1)} mA`;

        if (dbgTiltX) dbgTiltX.textContent = `${node.tiltX.toFixed(2)}°`;
        if (dbgTiltY) dbgTiltY.textContent = `${node.tiltY.toFixed(2)}°`;
        if (dbgZeroOffset) dbgZeroOffset.textContent = node.tiltX > 0.4 ? '⚠️ +0.12° Drift Warning' : '✓ < 0.02° (Calibrated)';
        if (dbgVibRms) dbgVibRms.textContent = `${node.vib.toFixed(2)} g`;
        if (dbgPcbTemp) dbgPcbTemp.textContent = `${node.temp.toFixed(1)} °C`;

        const rssiVal = -70 - Math.floor(Math.random() * 18);
        if (dbgRssi) dbgRssi.textContent = `${rssiVal} dBm`;
        if (dbgSnr) dbgSnr.textContent = `+${(9 + Math.random() * 3).toFixed(1)} dB`;
        if (dbgPdr) dbgPdr.textContent = node.status === 'high' ? '92.4% (Packet Re-tx)' : '99.8% (Optimal)';
    }

    window.runNodeSystemTest = function(scenarioTitle) {
        const node = activeNodesList.find(n => n.id === currentDiagNodeId) || { bat: 85, tiltX: 0.42, tiltY: 0.31, vib: 0.08, temp: 28.6, status: 'normal' };
        
        const testPanel = document.getElementById('diag-test-live-panel');
        const resultsBox = document.getElementById('diag-test-results-box');
        const progressFill = document.getElementById('diag-progress-fill');
        const timerBadge = document.getElementById('diag-countdown-timer');
        const logStream = document.getElementById('diag-log-stream');
        const spinnerIcon = document.getElementById('diag-spinner-icon');
        const statusText = document.getElementById('diag-test-status-text');

        if (!testPanel) return;

        testPanel.style.display = 'block';
        if (resultsBox) resultsBox.style.display = 'none';
        if (progressFill) progressFill.style.width = '0%';
        if (spinnerIcon) spinnerIcon.className = 'fa-solid fa-spinner fa-spin';
        if (statusText) statusText.textContent = scenarioTitle ? `Running targeted scenario test: "${scenarioTitle}" (5 seconds)...` : `Observing node data for system test (5 seconds)...`;

        if (logStream) {
            logStream.innerHTML = `<div class="diag-log-line info">[0.0s] 🟢 Initiating automated system diagnosis for Node ${currentDiagNodeId}...</div>`;
        }

        if (diagTestInterval) clearInterval(diagTestInterval);

        let step = 0;
        const totalSteps = 5;

        diagTestInterval = setInterval(() => {
            step++;
            const pct = (step / totalSteps) * 100;
            if (progressFill) progressFill.style.width = `${pct}%`;
            if (timerBadge) timerBadge.textContent = `00:0${totalSteps - step}`;

            const batV = (3.3 + (node.bat / 100) * 0.9).toFixed(2);

            if (step === 1 && logStream) {
                logStream.innerHTML += `<div class="diag-log-line info">[1.0s] ⚡ Power Subsystem Check... Voltage: ${batV}V (${node.bat}%), Solar: 5.12V - OK</div>`;
            } else if (step === 2 && logStream) {
                logStream.innerHTML += `<div class="diag-log-line info">[2.0s] 📐 Sampling IMU Accelerometer... Tilt X: ${node.tiltX.toFixed(2)}°, Tilt Y: ${node.tiltY.toFixed(2)}° - STABLE</div>`;
            } else if (step === 3 && logStream) {
                logStream.innerHTML += `<div class="diag-log-line info">[3.0s] 📊 Sampling 500 Hz Vibration Buffer... RMS: ${node.vib.toFixed(2)}g - NORMAL</div>`;
            } else if (step === 4 && logStream) {
                logStream.innerHTML += `<div class="diag-log-line info">[4.0s] 📡 Pinging Gateway... Gateway RSSI: -78 dBm, SNR: +10.4 dB - EXCELLENT</div>`;
            } else if (step === 5 && logStream) {
                logStream.innerHTML += `<div class="diag-log-line success">[5.0s] 💾 Verifying MCU Heap & Flash Storage... Free SRAM: 48.2KB, Watchdog: 0 Errors</div>`;
                logStream.innerHTML += `<div class="diag-log-line success">[5.0s] ✅ Real-time observation complete. Generating diagnostic health report...</div>`;
            }

            if (logStream) logStream.scrollTop = logStream.scrollHeight;

            if (step >= totalSteps) {
                clearInterval(diagTestInterval);
                diagTestInterval = null;

                if (spinnerIcon) spinnerIcon.className = 'fa-solid fa-circle-check';
                if (statusText) statusText.textContent = `System diagnostic check completed for Node ${currentDiagNodeId}.`;
                if (timerBadge) timerBadge.textContent = 'COMPLETE';

                // Display health results box
                setTimeout(() => {
                    renderDiagHealthReport(node);
                    if (resultsBox) resultsBox.style.display = 'block';
                }, 300);
            }
        }, 1000);
    };

    function renderDiagHealthReport(node) {
        const overallBanner = document.getElementById('diag-overall-banner');
        const bannerIcon = document.getElementById('diag-banner-icon');
        const scoreTitle = document.getElementById('diag-health-score-title');
        const summaryText = document.getElementById('diag-health-summary-text');

        let score = 96;
        let statusClass = 'green-banner';
        let iconClass = 'fa-solid fa-circle-check diag-banner-icon';
        let titleText = `Node Overall Health: 96% (OPTIMAL)`;
        let descText = `All hardware modules, sensor registers, and battery systems are functioning within normal parameters.`;

        if (node.status === 'high') {
            score = 38;
            statusClass = 'danger-banner';
            iconClass = 'fa-solid fa-circle-exclamation diag-banner-icon';
            titleText = `Node Overall Health: 38% (CRITICAL ALERT)`;
            descText = `High risk detected! Accelerometer drift (${node.tiltX.toFixed(2)}°) and RMS vibration anomaly exceed safety thresholds. Immediate inspection recommended.`;
        } else if (node.status === 'moderate' || node.bat < 30) {
            score = 68;
            statusClass = 'warning-banner';
            iconClass = 'fa-solid fa-triangle-exclamation diag-banner-icon';
            titleText = `Node Overall Health: 68% (MODERATE WARNING)`;
            descText = `Elevated vibration or low battery power level detected (${node.bat}%). Baseline recalibration advised.`;
        }

        if (overallBanner) {
            overallBanner.className = `diag-result-banner ${statusClass}`;
        }
        if (bannerIcon) {
            bannerIcon.className = iconClass;
        }
        if (scoreTitle) {
            scoreTitle.textContent = titleText;
        }
        if (summaryText) {
            summaryText.textContent = descText;
        }

        updateDiagDebugMetrics(currentDiagNodeId);
    }

    window.runScenarioDiagnostic = function(scenarioName) {
        switchDiagTab('tool');
        runNodeSystemTest(scenarioName);
    };

    window.downloadNodeLogs = function() {
        const node = activeNodesList.find(n => n.id === currentDiagNodeId) || { id: 'N16' };
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({
            nodeId: node.id,
            timestamp: new Date().toISOString(),
            status: node.status,
            battery: node.bat,
            tiltX: node.tiltX,
            tiltY: node.tiltY,
            vibration: node.vib,
            temperature: node.temp,
            mcu: "STM32L431 / ESP32-S3",
            watchdogErrors: 0,
            i2cSensors: ["MPU6050", "ADS1115", "BME280"],
            diagnosticResult: "HEALTHY"
        }, null, 2));
        const downloadAnchor = document.createElement('a');
        downloadAnchor.setAttribute("href", dataStr);
        downloadAnchor.setAttribute("download", `Node_${node.id}_Diagnostic_Dump.json`);
        document.body.appendChild(downloadAnchor);
        downloadAnchor.click();
        downloadAnchor.remove();
    };

    window.viewHistoryItemDetail = function(title) {
        alert(`Diagnostic History Detail for [${title}]:\n\nTarget Node: Node ${currentDiagNodeId}\nStatus: RESOLVED / PASSED\nLast Inspection: 2026/09/27 20:15:17\nTelemetry Baseline: Normal`);
    };

    // ==========================================================================
    // FIELD DEFORMATION & CRACK GEOLOCATION REPORTING SUITE
    // ==========================================================================
    let crackMarkersArray = [];

    window.openReportCrackModal = function() {
        const modal = document.getElementById('report-crack-modal-overlay');
        if (modal) modal.style.display = 'flex';
        requestGPSLocation();
    };

    window.closeReportCrackModal = function() {
        const modal = document.getElementById('report-crack-modal-overlay');
        if (modal) modal.style.display = 'none';
    };

    window.requestGPSLocation = function() {
        const statusText = document.getElementById('gps-status-text');
        const spinIcon = document.getElementById('gps-spin-icon');
        const latInput = document.getElementById('crack-lat-input');
        const lngInput = document.getElementById('crack-lng-input');

        if (spinIcon) spinIcon.style.display = 'inline-block';
        if (statusText) statusText.textContent = 'Acquiring live GPS location from your device...';

        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;
                    const acc = position.coords.accuracy ? position.coords.accuracy.toFixed(1) : '5.0';

                    if (latInput) latInput.value = lat.toFixed(6);
                    if (lngInput) lngInput.value = lng.toFixed(6);
                    if (statusText) statusText.textContent = `🟢 Live GPS Fixed: ${lat.toFixed(5)}° N, ${lng.toFixed(5)}° E (±${acc}m accuracy)`;
                    if (spinIcon) spinIcon.style.display = 'none';
                },
                (error) => {
                    const fallbackLat = currentCenterLat + (Math.random() - 0.5) * 0.002;
                    const fallbackLng = currentCenterLng + (Math.random() - 0.5) * 0.002;
                    if (latInput) latInput.value = fallbackLat.toFixed(6);
                    if (lngInput) lngInput.value = fallbackLng.toFixed(6);
                    if (statusText) statusText.textContent = `📍 Geolocation set to Map Area (${fallbackLat.toFixed(4)}°, ${fallbackLng.toFixed(4)}°) - Adjust manually if needed`;
                    if (spinIcon) spinIcon.style.display = 'none';
                },
                { enableHighAccuracy: true, timeout: 6000 }
            );
        } else {
            if (latInput) latInput.value = currentCenterLat.toFixed(6);
            if (lngInput) lngInput.value = currentCenterLng.toFixed(6);
            if (statusText) statusText.textContent = `📍 Geolocation set to Map Center (${currentCenterLat.toFixed(4)}°, ${currentCenterLng.toFixed(4)}°)`;
            if (spinIcon) spinIcon.style.display = 'none';
        }
    };

    window.saveCrackReport = function(event) {
        if (event) event.preventDefault();

        const lat = parseFloat(document.getElementById('crack-lat-input').value);
        const lng = parseFloat(document.getElementById('crack-lng-input').value);
        const type = document.getElementById('crack-type-select').value;
        const severity = document.getElementById('crack-severity-select').value;
        const width = parseFloat(document.getElementById('crack-width-input').value);
        const length = parseFloat(document.getElementById('crack-length-input').value);
        const notes = document.getElementById('crack-notes-textarea').value;

        const reportId = 'CR-' + Math.floor(1000 + Math.random() * 9000);
        const timestamp = new Date().toLocaleString();

        const reportData = {
            id: reportId,
            lat: lat,
            lng: lng,
            type: type,
            severity: severity,
            width: width,
            length: length,
            notes: notes || 'No extra remarks provided.',
            timestamp: timestamp
        };

        // Save into localStorage
        let savedReports = [];
        try {
            savedReports = JSON.parse(localStorage.getItem('minewatch_crack_reports') || '[]');
        } catch (e) {
            savedReports = [];
        }
        savedReports.push(reportData);
        localStorage.setItem('minewatch_crack_reports', JSON.stringify(savedReports));

        // Render marker on Leaflet map
        renderCrackMarkerOnMap(reportData);

        // Center map on crack location
        if (leafletMap) {
            leafletMap.flyTo([lat, lng], 17, { duration: 1 });
        }

        alert(`✅ Field Deformation Report [${reportId}] Saved Successfully!\n\nLocation: ${lat.toFixed(5)}° N, ${lng.toFixed(5)}° E\nType: ${type}\nSeverity: ${severity.toUpperCase()}\nEst. Width: ${width} mm | Length: ${length} m\n\nYour observation has been stored locally and pinned on the map.`);

        closeReportCrackModal();
    };

    function renderCrackMarkerOnMap(report) {
        if (!leafletMap) return;

        const iconHtml = `
            <div class="crack-marker-box" title="Field Report ${report.id}: ${report.type}">
                <div class="crack-marker-halo"></div>
                <div class="crack-marker-icon"><i class="fa-solid fa-triangle-exclamation"></i></div>
            </div>
        `;

        const customIcon = L.divIcon({
            className: 'crack-leaflet-node',
            html: iconHtml,
            iconSize: [40, 40],
            iconAnchor: [20, 20]
        });

        const marker = L.marker([report.lat, report.lng], { icon: customIcon }).addTo(leafletMap);
        
        marker.bindPopup(`
            <div style="font-family: sans-serif; padding: 4px;">
                <h4 style="color: #dc2626; margin: 0 0 4px 0; font-size: 14px;">⚠️ Field Report ${report.id}</h4>
                <div style="font-size: 12px; color: #334155; line-height: 1.4;">
                    <strong>Type:</strong> ${report.type}<br>
                    <strong>Severity:</strong> <span style="color:${report.severity === 'critical' ? '#dc2626' : '#d97706'}; font-weight:bold;">${report.severity.toUpperCase()}</span><br>
                    <strong>Width:</strong> ${report.width} mm | <strong>Length:</strong> ${report.length} m<br>
                    <strong>GPS:</strong> ${report.lat.toFixed(4)}°, ${report.lng.toFixed(4)}°<br>
                    <strong>Notes:</strong> ${report.notes}<br>
                    <small style="color:#64748b;">Logged: ${report.timestamp}</small>
                </div>
            </div>
        `);

        crackMarkersArray.push(marker);
    }

    function loadSavedCrackReports() {
        try {
            const savedReports = JSON.parse(localStorage.getItem('minewatch_crack_reports') || '[]');
            savedReports.forEach(r => renderCrackMarkerOnMap(r));
        } catch (e) {}
    }

    window.addEventListener('resize', () => {
        drawHeatmap('heatmap-canvas');
    });

    // ================= INITIALIZE ALL COMPONENTS =================
    initClock();
    initLeafletMap();
    initLatLngControls();
    drawHeatmap('heatmap-canvas');
    initCharts();
    initMapControls();
    initNodeSearchAndFilter();
    initLanguageSwitcher();
    
    if (activeNodesList.length > 0) {
        selectNode(activeNodesList[0].id);
        renderSequentialNodesTable();
    }
});
