/**
 * MineWatch - Dataset for Nodes, Telemetry, Trends & Alerts
 */

const NODES_DATA = [
    // Top Row
    { id: "N01", status: "normal", x: 32, y: 26, lat: "23.7951° N", lng: "86.4101° E", elev: 245, bat: 92, sig: -75, tiltX: 0.05, tiltY: 0.04, disp: 0.2, vib: 0.01, crack: 0.0, temp: 27.2 },
    { id: "N02", status: "normal", x: 42, y: 27, lat: "23.7948° N", lng: "86.4112° E", elev: 242, bat: 88, sig: -78, tiltX: 0.06, tiltY: 0.05, disp: 0.3, vib: 0.02, crack: 0.0, temp: 27.5 },
    { id: "N03", status: "normal", x: 48, y: 28, lat: "23.7945° N", lng: "86.4118° E", elev: 238, bat: 95, sig: -80, tiltX: 0.08, tiltY: 0.06, disp: 0.4, vib: 0.02, crack: 0.0, temp: 27.8 },
    { id: "N04", status: "normal", x: 53, y: 29, lat: "23.7942° N", lng: "86.4125° E", elev: 235, bat: 84, sig: -82, tiltX: 0.09, tiltY: 0.07, disp: 0.5, vib: 0.03, crack: 0.1, temp: 28.0 },
    { id: "N05", status: "normal", x: 60, y: 31, lat: "23.7939° N", lng: "86.4132° E", elev: 230, bat: 90, sig: -79, tiltX: 0.07, tiltY: 0.05, disp: 0.3, vib: 0.02, crack: 0.0, temp: 27.6 },
    { id: "N06", status: "normal", x: 67, y: 32, lat: "23.7935° N", lng: "86.4140° E", elev: 228, bat: 91, sig: -76, tiltX: 0.05, tiltY: 0.04, disp: 0.2, vib: 0.01, crack: 0.0, temp: 27.1 },

    // Row 2
    { id: "N07", status: "normal", x: 30, y: 33, lat: "23.7938° N", lng: "86.4098° E", elev: 236, bat: 86, sig: -81, tiltX: 0.07, tiltY: 0.06, disp: 0.4, vib: 0.02, crack: 0.0, temp: 27.7 },
    { id: "N08", status: "normal", x: 37, y: 34, lat: "23.7934° N", lng: "86.4107° E", elev: 232, bat: 87, sig: -83, tiltX: 0.11, tiltY: 0.09, disp: 0.8, vib: 0.03, crack: 0.1, temp: 28.1 },
    { id: "N09", status: "normal", x: 44, y: 35, lat: "23.7930° N", lng: "86.4115° E", elev: 226, bat: 80, sig: -85, tiltX: 0.15, tiltY: 0.12, disp: 1.1, vib: 0.04, crack: 0.1, temp: 28.3 },
    { id: "N10", status: "moderate", x: 50, y: 36, lat: "23.7927° N", lng: "86.4121° E", elev: 222, bat: 82, sig: -84, tiltX: 0.28, tiltY: 0.22, disp: 2.1, vib: 0.06, crack: 0.2, temp: 28.5 },
    { id: "N11", status: "normal", x: 57, y: 37, lat: "23.7924° N", lng: "86.4130° E", elev: 224, bat: 89, sig: -82, tiltX: 0.14, tiltY: 0.10, disp: 1.0, vib: 0.03, crack: 0.1, temp: 28.0 },
    { id: "N12", status: "normal", x: 64, y: 38, lat: "23.7920° N", lng: "86.4138° E", elev: 226, bat: 93, sig: -79, tiltX: 0.08, tiltY: 0.06, disp: 0.4, vib: 0.02, crack: 0.0, temp: 27.4 },

    // Center Hotspot Row (N16 is High)
    { id: "N13", status: "normal", x: 31, y: 40, lat: "23.7926° N", lng: "86.4099° E", elev: 228, bat: 85, sig: -84, tiltX: 0.10, tiltY: 0.08, disp: 0.7, vib: 0.02, crack: 0.0, temp: 27.9 },
    { id: "N14", status: "normal", x: 38, y: 40, lat: "23.7923° N", lng: "86.4108° E", elev: 220, bat: 83, sig: -86, tiltX: 0.18, tiltY: 0.15, disp: 1.4, vib: 0.04, crack: 0.2, temp: 28.4 },
    { id: "N15", status: "moderate", x: 44, y: 41, lat: "23.7922° N", lng: "86.4116° E", elev: 218, bat: 79, sig: -85, tiltX: 0.32, tiltY: 0.25, disp: 2.5, vib: 0.07, crack: 0.3, temp: 28.6 },
    { id: "N16", status: "high", x: 50, y: 42, lat: "23.7921° N", lng: "86.4123° E", elev: 215, bat: 78, sig: -87, tiltX: 0.42, tiltY: 0.31, disp: 3.2, vib: 0.08, crack: 0.4, temp: 28.6 },
    { id: "N17", status: "moderate", x: 57, y: 42, lat: "23.7919° N", lng: "86.4131° E", elev: 217, bat: 81, sig: -86, tiltX: 0.34, tiltY: 0.26, disp: 2.7, vib: 0.07, crack: 0.3, temp: 28.5 },
    { id: "N18", status: "normal", x: 64, y: 43, lat: "23.7916° N", lng: "86.4139° E", elev: 221, bat: 90, sig: -80, tiltX: 0.09, tiltY: 0.07, disp: 0.5, vib: 0.02, crack: 0.0, temp: 27.6 },

    // Lower Mid Row
    { id: "N19", status: "normal", x: 29, y: 47, lat: "23.7915° N", lng: "86.4095° E", elev: 232, bat: 87, sig: -82, tiltX: 0.06, tiltY: 0.05, disp: 0.3, vib: 0.01, crack: 0.0, temp: 27.3 },
    { id: "N20", status: "normal", x: 36, y: 47, lat: "23.7912° N", lng: "86.4105° E", elev: 226, bat: 84, sig: -83, tiltX: 0.12, tiltY: 0.09, disp: 0.9, vib: 0.03, crack: 0.1, temp: 28.0 },
    { id: "N21", status: "moderate", x: 43, y: 47, lat: "23.7910° N", lng: "86.4114° E", elev: 220, bat: 76, sig: -88, tiltX: 0.29, tiltY: 0.23, disp: 2.2, vib: 0.12, crack: 0.3, temp: 28.4 },
    { id: "N22", status: "normal", x: 50, y: 48, lat: "23.7908° N", lng: "86.4122° E", elev: 219, bat: 82, sig: -84, tiltX: 0.16, tiltY: 0.13, disp: 1.2, vib: 0.04, crack: 0.2, temp: 28.2 },
    { id: "N23", status: "normal", x: 57, y: 49, lat: "23.7905° N", lng: "86.4130° E", elev: 223, bat: 88, sig: -81, tiltX: 0.10, tiltY: 0.08, disp: 0.6, vib: 0.02, crack: 0.0, temp: 27.8 },
    { id: "N24", status: "normal", x: 63, y: 50, lat: "23.7902° N", lng: "86.4137° E", elev: 227, bat: 92, sig: -77, tiltX: 0.05, tiltY: 0.04, disp: 0.2, vib: 0.01, crack: 0.0, temp: 27.2 },

    // Bottom Row
    { id: "N25", status: "normal", x: 32, y: 52, lat: "23.7901° N", lng: "86.4099° E", elev: 238, bat: 91, sig: -79, tiltX: 0.04, tiltY: 0.03, disp: 0.2, vib: 0.01, crack: 0.0, temp: 27.1 },
    { id: "N26", status: "normal", x: 39, y: 53, lat: "23.7898° N", lng: "86.4108° E", elev: 234, bat: 89, sig: -80, tiltX: 0.07, tiltY: 0.05, disp: 0.4, vib: 0.02, crack: 0.0, temp: 27.5 },
    { id: "N27", status: "normal", x: 46, y: 54, lat: "23.7895° N", lng: "86.4116° E", elev: 229, bat: 86, sig: -82, tiltX: 0.09, tiltY: 0.07, disp: 0.5, vib: 0.02, crack: 0.0, temp: 27.7 },
    { id: "N28", status: "normal", x: 53, y: 55, lat: "23.7892° N", lng: "86.4124° E", elev: 228, bat: 88, sig: -81, tiltX: 0.08, tiltY: 0.06, disp: 0.4, vib: 0.02, crack: 0.0, temp: 27.6 },
    { id: "N29", status: "normal", x: 59, y: 56, lat: "23.7889° N", lng: "86.4131° E", elev: 233, bat: 94, sig: -78, tiltX: 0.05, tiltY: 0.04, disp: 0.2, vib: 0.01, crack: 0.0, temp: 27.3 },
    { id: "N30", status: "normal", x: 65, y: 57, lat: "23.7886° N", lng: "86.4139° E", elev: 236, bat: 96, sig: -75, tiltX: 0.03, tiltY: 0.02, disp: 0.1, vib: 0.01, crack: 0.0, temp: 27.0 }
];

// Time series trends (00:00 to 18:00) for Node N16 and fallback default
const TIME_LABELS = ["00:00", "03:00", "06:00", "09:00", "12:00", "15:00", "18:00"];

const TRENDS_DATA_MAP = {
    "N16": {
        tiltX: [0.08, 0.12, 0.15, 0.21, 0.27, 0.35, 0.42],
        tiltY: [0.04, 0.07, 0.10, 0.15, 0.20, 0.26, 0.31],
        disp: [0.1, 0.3, 0.5, 0.9, 1.4, 2.2, 3.2],
        vib: [0.04, 0.11, 0.05, 0.15, 0.07, 0.12, 0.08]
    },
    "N15": {
        tiltX: [0.06, 0.09, 0.12, 0.17, 0.22, 0.28, 0.32],
        tiltY: [0.03, 0.05, 0.08, 0.12, 0.16, 0.21, 0.25],
        disp: [0.1, 0.2, 0.4, 0.7, 1.1, 1.8, 2.5],
        vib: [0.03, 0.08, 0.04, 0.10, 0.05, 0.09, 0.07]
    },
    "N17": {
        tiltX: [0.07, 0.10, 0.13, 0.18, 0.23, 0.29, 0.34],
        tiltY: [0.04, 0.06, 0.09, 0.13, 0.17, 0.22, 0.26],
        disp: [0.1, 0.3, 0.5, 0.8, 1.2, 1.9, 2.7],
        vib: [0.04, 0.09, 0.05, 0.11, 0.06, 0.10, 0.07]
    },
    "default": {
        tiltX: [0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08],
        tiltY: [0.01, 0.02, 0.02, 0.03, 0.04, 0.05, 0.06],
        disp: [0.0, 0.1, 0.1, 0.2, 0.3, 0.4, 0.5],
        vib: [0.01, 0.03, 0.02, 0.04, 0.02, 0.03, 0.02]
    }
};
