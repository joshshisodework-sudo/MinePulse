import json
import re

languages = {
    'hi': {
        'brandName': 'माइनवॉच', 'brandSubtitle': 'खदान धंसने की निगरानी', 'nodesOnline': 'सक्रिय नोड्स', 'activeAlerts': 'सक्रिय अलर्ट', 
        'highestRisk': 'उच्चतम जोखिम', 'systemOperational': 'प्रणाली चालू है', 'recentAlerts': 'हाल के अलर्ट', 'nodesDirectory': 'क्रमिक सेंसर नोड्स निर्देशिका', 
        'nodeId': 'नोड आईडी', 'status': 'स्थिति', 'lat': 'अक्षांश:', 'lng': 'देशांतर:', 'go': 'जाओ', 'jhariaCoalfield': '📍 झरिया कोयला क्षेत्र (30 नोड)', 
        'raniganjField': '📍 रानीगंज क्षेत्र (12 नोड)', 'singrauliPitMine': '📍 सिंगरौली खदान (18 नोड)', 'korbaOperations': '📍 कोरबा खदान (15 नोड)', 
        'nodes': 'नोड्स:', 'plant': 'लगाएं', 'clear': 'साफ़ करें', 'nodeWord': 'नोड', 'offlineWord': 'ऑफ़लाइन', 'highRiskIndicators': 'उच्च जोखिम संकेतक', 
        'increasingDisplacement': 'बढ़ता विस्थापन', 'elevatedVibration': 'उच्च कंपन', 'highRisk': 'उच्च जोखिम', 'warning': 'चेतावनी', 'normal': 'सामान्य', 
        'high': 'उच्च', 'highRiskZoneDetected': 'उच्च जोखिम क्षेत्र का पता चला', 'potentialSubsidence': 'संभावित धंसाव गतिविधि', 
        'detailedTelemetry': 'विस्तृत टेलीमेट्री एनालिटिक्स और ट्रेंड चार्ट', 'tiltX': 'झुकाव (X)', 'tiltY': 'झुकाव (Y)', 'displacement': 'विस्थापन', 
        'vibration': 'कंपन (RMS)', 'crackWidth': 'दरार की चौड़ाई', 'temperature': 'तापमान', 'action': 'कार्रवाई', 'elevation': 'ऊंचाई'
    },
    'or': {
        'brandName': 'ମାଇନ୍ ୱାଚ୍', 'brandSubtitle': 'ଖଣି ଦବିବା ତଦାରଖ', 'nodesOnline': 'ସକ୍ରିୟ ନୋଡ୍', 'activeAlerts': 'ସକ୍ରିୟ ସତର୍କତା', 
        'highestRisk': 'ସର୍ବାଧିକ ବିପଦ', 'systemOperational': 'ସିଷ୍ଟମ୍ କାର୍ଯ୍ୟକ୍ଷମ', 'recentAlerts': 'ସାମ୍ପ୍ରତିକ ସତର୍କତା', 'nodesDirectory': 'କ୍ରମିକ ସେନ୍ସର ନୋଡ୍ ଡିରେକ୍ଟୋରୀ', 
        'nodeId': 'ନୋଡ୍ ଆଇଡି', 'status': 'ସ୍ଥିତି', 'lat': 'ଅକ୍ଷାଂଶ:', 'lng': 'ଦ୍ରାଘିମା:', 'go': 'ଯାଆନ୍ତୁ', 'jhariaCoalfield': '📍 ଝରିଆ କୋଇଲା ଖଣି (୩୦ ନୋଡ୍)', 
        'raniganjField': '📍 ରାଣୀଗଞ୍ଜ କ୍ଷେତ୍ର (୧୨ ନୋଡ୍)', 'singrauliPitMine': '📍 ସିଙ୍ଗରୌଲି ଖଣି (୧୮ ନୋଡ୍)', 'korbaOperations': '📍 କୋରବା ଖଣି (୧୫ ନୋଡ୍)', 
        'nodes': 'ନୋଡ୍:', 'plant': 'ଲଗାନ୍ତୁ', 'clear': 'ସଫା କରନ୍ତୁ', 'nodeWord': 'ନୋଡ୍', 'offlineWord': 'ଅଫଲାଇନ୍', 'highRiskIndicators': 'ଉଚ୍ଚ ବିପଦ ସୂଚକ', 
        'increasingDisplacement': 'ବୃଦ୍ଧି ପାଉଥିବା ବିସ୍ଥାପନ', 'elevatedVibration': 'ଉଚ୍ଚ କମ୍ପନ', 'highRisk': 'ଉଚ୍ଚ ବିପଦ', 'warning': 'ଚେତାବନୀ', 'normal': 'ସାଧାରଣ', 
        'high': 'ଉଚ୍ଚ', 'highRiskZoneDetected': 'ଉଚ୍ଚ ବିପଦ ଅଞ୍ଚଳ ଚିହ୍ନଟ ହୋଇଛି', 'potentialSubsidence': 'ସମ୍ଭାବ୍ୟ ଦବିବା ଗତିବିଧି', 
        'detailedTelemetry': 'ବିସ୍ତୃତ ଟେଲିମେଟ୍ରି ବିଶ୍ଳେଷଣ', 'tiltX': 'ଢାଲ (X)', 'tiltY': 'ଢାଲ (Y)', 'displacement': 'ବିସ୍ଥାପନ', 
        'vibration': 'କମ୍ପନ (RMS)', 'crackWidth': 'ଫାଟର ପ୍ରସ୍ଥ', 'temperature': 'ତାପମାତ୍ରା', 'action': 'କାର୍ଯ୍ୟ', 'elevation': 'ଉଚ୍ଚତା'
    },
    'bn': {
        'brandName': 'মাইনওয়াচ', 'brandSubtitle': 'খনি ধস পর্যবেক্ষণ', 'nodesOnline': 'সক্রিয় নোড', 'activeAlerts': 'সক্রিয় সতর্কতা',
        'highestRisk': 'সর্বোচ্চ ঝুঁকি', 'systemOperational': 'সিস্টেম চালু আছে', 'recentAlerts': 'সাম্প্রতিক সতর্কতা', 'nodesDirectory': 'ক্রমিক সেন্সর নোড ডিরেক্টরি',
        'nodeId': 'নোড আইডি', 'status': 'অবস্থা', 'lat': 'অক্ষাংশ:', 'lng': 'দ্রাঘিমাংশ:', 'go': 'যান', 'jhariaCoalfield': '📍 ঝরিয়া কয়লাক্ষেত্র (৩০ নোড)',
        'raniganjField': '📍 রানিগঞ্জ ক্ষেত্র (১২ নোড)', 'singrauliPitMine': '📍 সিংরাউলি খনি (১৮ নোড)', 'korbaOperations': '📍 কোরবা খনি (১৫ নোড)',
        'nodes': 'নোড:', 'plant': 'উদ্ভিদ', 'clear': 'পরিষ্কার করুন', 'nodeWord': 'নোড', 'offlineWord': 'অফলাইন', 'highRiskIndicators': 'উচ্চ ঝুঁকি নির্দেশক',
        'increasingDisplacement': 'ক্রমবর্ধমান স্থানচ্যুতি', 'elevatedVibration': 'উচ্চ কম্পন', 'highRisk': 'উচ্চ ঝুঁকি', 'warning': 'সতর্কতা', 'normal': 'স্বাভাবিক',
        'high': 'উচ্চ', 'highRiskZoneDetected': 'উচ্চ ঝুঁকি অঞ্চল সনাক্ত করা হয়েছে', 'potentialSubsidence': 'সম্ভাব্য ধস কার্যকলাপ',
        'detailedTelemetry': 'বিস্তারিত টেলিমেট্রি বিশ্লেষণ', 'tiltX': 'ঢাল (X)', 'tiltY': 'ঢাল (Y)', 'displacement': 'স্থানচ্যুতি',
        'vibration': 'কম্পন (RMS)', 'crackWidth': 'ফাটলের প্রস্থ', 'temperature': 'তাপমাত্রা', 'action': 'কাজ', 'elevation': 'উচ্চতা'
    },
    'te': {
        'brandName': 'మైన్‌వాచ్', 'brandSubtitle': 'గని కుంగుబాటు పర్యవేక్షణ', 'nodesOnline': 'ఆన్‌లైన్ నోడ్లు', 'activeAlerts': 'క్రియాశీల హెచ్చరికలు',
        'highestRisk': 'అత్యధిక ప్రమాదం', 'systemOperational': 'సిస్టమ్ పనిచేస్తోంది', 'recentAlerts': 'ఇటీవలి హెచ్చరికలు', 'nodesDirectory': 'క్రమ సెన్సార్ నోడ్ల డైరెక్టరీ',
        'nodeId': 'నోడ్ ID', 'status': 'స్థితి', 'lat': 'అక్షాంశం:', 'lng': 'రేఖాంశం:', 'go': 'వెళ్ళు', 'jhariaCoalfield': '📍 ఝరియా బొగ్గు గని (30 నోడ్లు)',
        'raniganjField': '📍 రాణిగంజ్ ఫీల్డ్ (12 నోడ్లు)', 'singrauliPitMine': '📍 సింగ్రౌలి గని (18 నోడ్లు)', 'korbaOperations': '📍 కోర్బా ఆపరేషన్స్ (15 నోడ్లు)',
        'nodes': 'నోడ్లు:', 'plant': 'నాటండి', 'clear': 'శుభ్రం చేయండి', 'nodeWord': 'నోడ్', 'offlineWord': 'ఆఫ్‌లైన్', 'highRiskIndicators': 'అధిక ప్రమాద సూచికలు',
        'increasingDisplacement': 'పెరుగుతున్న స్థానభ్రంశం', 'elevatedVibration': 'పెరిగిన కంపనం', 'highRisk': 'అధిక ప్రమాదం', 'warning': 'హెచ్చరిక', 'normal': 'సాధారణం',
        'high': 'అధిక', 'highRiskZoneDetected': 'అధిక ప్రమాద ప్రాంతం గుర్తించబడింది', 'potentialSubsidence': 'సంభావ్య కుంగుబాటు కార్యాచరణ',
        'detailedTelemetry': 'వివరణాత్మక టెలిమెట్రీ విశ్లేషణ', 'tiltX': 'వంపు (X)', 'tiltY': 'వంపు (Y)', 'displacement': 'స్థానభ్రంశం',
        'vibration': 'కంపనం (RMS)', 'crackWidth': 'పగుళ్ల వెడల్పు', 'temperature': 'ఉష్ణోగ్రత', 'action': 'చర్య', 'elevation': 'ఎత్తు'
    }
}

# Auto-fill other languages using generic placeholders to avoid a huge script
other_langs = ['ta', 'mr', 'gu', 'ur', 'kn', 'ml', 'pa', 'as', 'mai', 'sat', 'ks', 'ne', 'kok', 'sd', 'doi', 'mni', 'brx', 'sa']

for lang in other_langs:
    languages[lang] = {k: f"[{lang.upper()}] {v}" for k, v in languages['hi'].items()} # Fallback with prefix

with open('/home/neh/sih/js/app.js', 'r') as f:
    content = f.read()

translations_str = json.dumps(languages, ensure_ascii=False, indent=12)
pattern = r'const translations = \{[\s\S]*?\n\s*\};'
replacement = f'const translations = {translations_str};'

new_content = re.sub(pattern, replacement, content)

with open('/home/neh/sih/js/app.js', 'w') as f:
    f.write(new_content)
